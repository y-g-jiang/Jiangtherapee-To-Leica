/* -*- C++ -*-
 * File: nikonhe.cpp
 * Copyright (C) 2024 Alexey Danilchenko
 * Copyright (C) 2024-2026 Alex Tutubalin, LibRaw LLC
 *
   Nikon HE/HE* decoder

LibRaw is free software; you can redistribute it and/or modify
it under the terms of the one of two licenses as you choose:

1. GNU LESSER GENERAL PUBLIC LICENSE version 2.1
   (See file LICENSE.LGPL provided in LibRaw distribution archive for details).

2. COMMON DEVELOPMENT AND DISTRIBUTION LICENSE (CDDL) Version 1.0
   (See file LICENSE.CDDL provided in LibRaw distribution archive for details).

 */


//#include "libraw/libraw.h"
#ifdef _WIN32
#define NOMINMAX
#endif
#include "../../internal/libraw_cxx_defs.h"
#include <algorithm>
#include <cassert>
#include <cstddef>
#include <stdint.h>
#include <math.h>
#include <memory.h>
#include <stdlib.h>
#include <string>
#include <vector>

#if !defined(_WIN32)
#if LibRawBigEndian
#define be64p(x) (x)
#define be32(x) (x)
#define be16(x) (x)
#else
#define be64p(x) __builtin_bswap64(*(x))
#define be32(x) __builtin_bswap32((x))
#define be16(x) __builtin_bswap16((x))
#endif
#else
#define be64p(x) _byteswap_uint64(*(x))
#define be32(x) _byteswap_ulong(x)
#define be16(x) _byteswap_ushort(x)
#endif

#if defined(__clang__) || defined(__GNUG__)
#define libraw_inline inline __attribute__((always_inline))
#elif defined(_MSC_VER) && _MSC_VER > 1400
#define libraw_inline __forceinline
#else
#define libraw_inline inline
#endif

#define XS_MAX_IMAGE_COMPONENTS 4

// std::clamp may not be available so define our own
#define clamp(x, l, u) ((x) < (l) ? (l) : ((x) > (u) ? (u) : (x)))

// Tico coding fixes JpegXs Ng parameter to 4 through the code
#define N_COEFF_IN_GROUP 4
// Tico coding fixes JpegXs Br parameter to 4 through the code
#define BITS_IN_BITPLANE 4
// Max size of JpegXS header
#define JPEG_XS_HEADER_SIZE 0xE8


enum err_code_t : int32_t
{
    NIKONHE_SUCCESS = 0,
	NIKONHE_GENERIC_ERROR = 1,
};

enum jpeg_xs_header_tags : uint16_t
{
    XS_MARKER_SOC = 0xff10,
    XS_MARKER_EOC = 0xff11,
    XS_MARKER_PIH = 0xff12,
    XS_MARKER_CDT = 0xff13,
    XS_MARKER_WGT = 0xff14,
    XS_MARKER_COM = 0xff15,
    XS_MARKER_NLT = 0xff16,
    XS_MARKER_CWD = 0xff17,
    XS_MARKER_CTS = 0xff18,
    XS_MARKER_CRG = 0xff19,
    XS_MARKER_SLH = 0xff20,
    XS_MARKER_CAP = 0xff50
};

enum bands_progression_order_t : int32_t  // ppoc - only 3 models are supported
{
    NIKONHE_PPOC_RPBC = 0x0,  // supported - JPEG XS standard
    NIKONHE_PPOC_VCGH = 0x1,  // supported - TICO specific from JpegXS ref.4
    NIKONHE_PPOC_UNUSED = 0x2,
    NIKONHE_PPOC_VGCH = 0x3,  // supported - TICO specific derived from VCGH
};

enum idwt_state_t : int32_t
{
    IDWT_STATE_HFM1_FOT = 0,
    IDWT_STATE_LF0_FOT = 1,
    IDWT_STATE_LF0_FOI = 2,
    IDWT_STATE_LF0_UP = 3,
    IDWT_STATE_HF0 = 4,
    IDWT_STATE_HF0_FOI = 5,
    IDWT_STATE_LF_UP = 6,
    IDWT_STATE_LF = 7,
    IDWT_STATE_HF = 8,
    IDWT_STATE_GHOST = 9,
    IDWT_STATE_GHOST_UP = 10,
    IDWT_FINAL = 11,
};

enum raw_gamma_type_t : int32_t
{
    raw_gamma_type_none = -1,
    raw_gamma_type_not_used = 0,    // same as linear
    raw_gamma_type_curve_inversion = 1,
    raw_gamma_type_linear = 2,      // using this basically omits gamma
    raw_gamma_type_shifted = 3,
};


// Structures and classes

class bitstream_reader
{
public:
    bitstream_reader(): w64(0), data_ptr(0), data_end(0), bits_left(0) {}
    bitstream_reader(const void *data, const int len) { init(data, len); }
    bitstream_reader(const void *data, const void *data_end_ptr)
    { init(data, data_end_ptr); }
    bitstream_reader(const bitstream_reader& c)
        : w64(c.w64), data_ptr(c.data_ptr), data_end(c.data_end), bits_left(c.bits_left) {}

    void init(const void *data, const void *data_end_ptr)
    {
        data_ptr = (const uint32_t *)(((uint64_t)data & ~7) + 8);
        data_end = (const uint32_t *)(((uint64_t)data_end_ptr + 3) & ~3);
        bits_left = 64 - 8 * ((uint64_t)data & 7);
        w64 = be64p((const uint64_t *)((uint64_t)data & ~7)) << (64 - bits_left);
        fill32();
    }

    void init(const void *data, const int len) { init(data, (uint8_t*)data+len); }

    uint8_t* current_ptr()
    {
        return (uint8_t *)data_ptr + ((32 - bits_left) >> 3) - 4;
    }

    void discard_long(int n_bits)
    {
        int n32 = n_bits >> 5;
        if (n32 > 2)
        {
            data_ptr += n32 - 2;
            n32 = 2;
        }
        while (n32-- > 0)
        {
            w64 <<= 32;
            bits_left -= 32;
            fill32();
        }
        w64 <<= n_bits & 0x1F;
        bits_left -= n_bits & 0x1F;
        fill32();
    }

    uint32_t read(int n_bits)
    {
        uint32_t val = w64 >> (64 - n_bits);
        w64 <<= n_bits;
        bits_left -= n_bits;
        fill32();
        return val;
    }

    void align(int n_bits)
    {
        int alignb = (n_bits - 1) & bits_left;
        if (alignb)
        {
            w64 <<= alignb;
            bits_left -= alignb;
            fill32();
        }
    }

    int used_bits(const void *data_start)
    {
        return 8 * ((uint8_t*)data_ptr - (uint8_t*)data_start) - bits_left;
    }

    int bits_diff_from(bitstream_reader *from)
    {
        return from->bits_left - bits_left + 8 * ((char *)data_ptr - (char *)from->data_ptr);
    }

    int read_unary_signed()
    {
        // essentially the same as reading signed with UNARY_ALPHABET_0 in JPEG XS reference
        const static int8_t unary_lut[256] =
        {
            0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
            0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
            0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
            0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
            0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
            0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
            0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
            0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
            1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,
            1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,  1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1,
            2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,  2,
            -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2, -2,
            3,  3,  3,  3,  3,  3,  3,  3, -3, -3, -3, -3, -3, -3, -3, -3,
            4,  4,  4,  4, -4, -4, -4, -4,  5,  5, -5, -5,  6, -6, 10,  0
        };

        int val = 0;
        if ((peek(8) & 0xFE) == 0xFE)
        {
            val = 7;
            w64 <<= 7;
            bits_left -= 7;
            fill32();
            while (val<15 && read(1))
                ++val;
            if (read(1))
                return -val;
        }
        else
        {
            val = unary_lut[peek(8)];
            w64 <<= abs(val) + 2 - (val == 0);
            bits_left -= abs(val) + 2 - (val == 0);
            fill32();
        }
        return val;

        // less performant but easier to read
    /*
        int cnt = 0;
        while (cnt < 15 && read(1))
            ++cnt;
        if (cnt && read(1))
            return -cnt;
        return cnt;
    */
    }

    uint32_t read_unary_unsigned_bounded()
    {
        int cnt = 1;
        while (cnt <= bits_left && (peek(cnt) & 1))
            ++cnt;
        w64 <<= cnt;
        bits_left -= cnt;
        fill32();
        return cnt - 1;

        // less performant but easier to read
    /*
        int cnt = 0;
        while (cnt<64 && read(1))
            ++cnt;
        return cnt;
    */
    }

    // get dequantized coeff. for
    void get_coeffs_deadzone_dq_nosigns(
        uint32_t* coeffs,
        int n_bits,
        int gtli_scale, // truncation. bit position
        int scale)
    {
        // read interleaved N bits for the code group
        for (int bit = 0; bit < n_bits; ++bit)
            for (int i=0; i<N_COEFF_IN_GROUP; ++i)
            {
                coeffs[i] <<= 1;
                coeffs[i] |= read(1);
            }

        uint32_t truncation_point = gtli_scale ? 1 << (gtli_scale-1) : 0;
        for (int i=0; i<N_COEFF_IN_GROUP; ++i)
            if (coeffs[i])
                coeffs[i] = ((coeffs[i] << gtli_scale) | truncation_point) << scale;
    }

    void get_coeffs_deadzone_dq(
        int32_t* coeffs,
        int n_bits,
        int gtli_scale, // truncation. bit position
        int scale)
    {
        bitstream_reader bsr_sign(*this);
        discard_long(N_COEFF_IN_GROUP);

        get_coeffs_deadzone_dq_nosigns((uint32_t*)coeffs, n_bits, gtli_scale, scale);

        // now apply signs
        for (int i=0; i<N_COEFF_IN_GROUP; ++i)
            if (bsr_sign.read(1) && coeffs[i])
                coeffs[i] = -coeffs[i];
    }

    void get_coeffs_uniform_dq_nosigns(
        uint32_t *coeffs,
        int n_bits,
        int gtli_scale,
        int scale)
    {
        const static uint32_t bc[15] =
        {
            0x15555, 0x12492, 0x11111,
            0x10842, 0x10410, 0x10204,
            0x10101, 0x10080, 0x10040,
            0x10020, 0x10010, 0x10008,
            0x10004, 0x10002, 0x10001
        };

        // read interleaved N bits for the code group
        for (int bit = 0; bit < n_bits; ++bit)
            for (int i=0; i<N_COEFF_IN_GROUP; ++i)
            {
                coeffs[i] <<= 1;
                coeffs[i] |= read(1);
            }

        for (int i=0; i<N_COEFF_IN_GROUP; ++i)
        {
            coeffs[i] *= bc[n_bits - 1]; // low 32 bits
            coeffs[i] >>= 16 - gtli_scale;
            coeffs[i] <<= scale;
        }
    }

    void get_coeffs_uniform_dq(
        int32_t *coeffs,
        int n_bits,
        int gtli_scale,
        int scale)
    {
        bitstream_reader bsr_sign(*this);
        discard_long(N_COEFF_IN_GROUP);

        get_coeffs_uniform_dq_nosigns((uint32_t*)coeffs, n_bits, gtli_scale, scale);

        // now apply signs
        for (int i=0; i<N_COEFF_IN_GROUP; ++i)
            if (bsr_sign.read(1) && coeffs[i])
                coeffs[i] = -coeffs[i];
    }

private:

    uint32_t peek(int n_bits)
    {
        return w64 >> (64 - n_bits);
    }

    void fill32()
    {
        if (bits_left < 32)
        {
            uint64_t msk = data_ptr >= data_end ? 0 : be32(*data_ptr);
            w64 |= msk << (32 - bits_left);
            ++data_ptr;
            bits_left += 32;
        }
    }

    uint64_t w64;           // current data word (double sized - 64 bits)
    const uint32_t *data_ptr;    // next word data pointer
    const uint32_t *data_end;    // end of data pointer
    int bits_left;                // num bits left in a word
};

struct packet_data_t
{
    uint8_t *sig_start;
    uint8_t *gcli_start;
    uint8_t *data_start;
    uint8_t *sign_start;
    unsigned int sig_len;
    unsigned int gcli_len;
    unsigned int data_len;
    unsigned int sign_len;
    bool pkt_is_raw;
    uint8_t data_start_bit_offset;
    uint8_t gcli_start_bit_offset;
};

struct gtli_pairs_t
{
    uint8_t truncation[72];
    uint8_t data[72];
};

struct precinct_data_t
{
    unsigned int prec_idx;
    unsigned int prec_len;
    int padding_len;
    uint8_t quantisation;
    uint8_t refinement;
    packet_data_t packets[10];
    uint8_t sb_gcli_coding[72];
    gtli_pairs_t gtlis_sb;
    gtli_pairs_t interframe_gtlis_sb;
};

struct gamma_data_t
{
    uint8_t enabled;
    int pregamma_offset;
    raw_gamma_type_t gamma_type;
    long double gamma_value;
    int in_bitdepth;
    int out_bitdepth;
    int offset_16;
    int offset_sqrt;
    int k_val;
    int k_flip;
    int r_val;
    int r_flip;
    uint8_t hardcoded_bayer_tweaks;
};

struct seg_grp_data_t
{
    int ofs_grp;
    int ofs_coef;
    int len_grp;
};

// image specific structures and decoding aiding structures
struct nikonhe_image
{
    int w_pix;
    int h_pix;
    int h_pad_pix;
    int depth;
    int n_comp;
    int h_lvl;
    int v_lvl;
    int v_lines;
    int input_scale;
    int prequant;
    bool is_422;
    bool is_uniform_q;
    bool signs_separate;
    bool is_run_mode_zero_coeff;
    bool is_nikonhe_long_packet_hdr;
    bands_progression_order_t ppoc;
    gamma_data_t gamma_data;
    int64_t total_bytes;
    int slh_pix;  // slice height in pixels
    int pkt_grp;
    unsigned int num_sb;    // subbands count and mapping
    uint8_t sb_priorities[72];
	int8_t sb_by_priorities[72];
	int8_t sb_seg[72][2];
    uint8_t sb_gains[72];
    unsigned int nb_seg;
    int8_t pos_seg[4][4][6];
    seg_grp_data_t seg_grp[52];
    int sp_seg[10][52];
    int sp_seg_size[10];
    unsigned int seg_sig_size[52];
    unsigned int nb_pkt;
    int8_t seg_pkt[52];
    int8_t seg_sb[52];
    int8_t seg_pv[52];
    unsigned int sp_chunks[10];
    int sp_sb_order[120];
    int sp_dual[10];
    unsigned int semi_comp_chunks[4];
    int line_stride;
    int skip_decomp[4];
    int odd_ofs[4][3][6];
	int8_t sp_res[10];
	int8_t seg_res[52];
};

struct gamma_lut_t
{
    int size;
    int lut[0x20001];
};

struct nikonhe_decoder
{
    nikonhe_image img;
    const uint8_t *data_buf;
    size_t data_len;
    size_t data_ofs;
    int32_t *in_bayer_stage1;
    int32_t *in_bayer_stage2;
    gamma_lut_t gamma_lut;
    void *output_buffer;
    size_t output_line_stride;
    int output_height;
};

// this relies on structural bit allocation - not sure how portable that is
struct jpegxs_pih_t
{
    unsigned int codestream_size;
    uint16_t profile;
    uint16_t level;
    uint16_t width_img;
    uint16_t height_img;
    uint16_t width_precinct;
    uint16_t height_slice;
    uint8_t n_components;
    uint8_t n_coef_per_code_group;
    uint8_t n_code_group_per_sig_group;
    uint8_t nominal_precision_wavelet;

    uint8_t bits_bitplane_raw : 4;
    uint8_t fractional_bits_wavelet : 4;

    uint8_t colour_transform : 4;
    uint8_t progr_order_bands_precinct : 3; // ppoc
    uint8_t slice_coding_mode : 1;

    uint8_t n_ver_wavelet_transform : 4;
    uint8_t n_hor_wavelet_transform : 4;

    uint8_t run_mode : 2;
    uint8_t sign_handling_strategy : 2;
    uint8_t quantizer_type : 4;    // tico differs from JpegXS spec as there quantizer type is 2 bits with
                                   // two others used for different purpouse
};

// this relies on structural bit allocation - not sure how portable that is
struct nikonhe_capabilities_t
{
    uint8_t nikonhe_cap_qux_dwt53_bayer : 1;
    uint8_t nikonhe_cap_gamma_transform : 1;       // non-linear/gamma
    uint8_t nikonhe_cap_custom_prog_orders : 1;    // cust PPOC
    uint8_t nikonhe_cap_b_gains : 1;               // some sort of gains
    uint8_t nikonhe_cap_interframe : 1;            // interframe support - not implemented
    uint8_t nikonhe_cap_ver_first_of_slice : 1;
    uint8_t nikonhe_cap_no_raw_mode_gcli : 1;      // packet based raw mode?
    uint8_t nikonhe_cap_long_pkt_hdr : 1;

    uint8_t unused_bits : 6;
    uint8_t nikonhe_cap_diff_vh_lvls_per_comp : 1;
    uint8_t nikonhe_cap_qux_ycbcr_bayer : 1;
};

struct tile_buf
{
    const uint8_t *in_buf;
    size_t in_len;
};

struct stage1_data
{
    uint8_t h_gcli0[0x34];  // 52
    uint8_t *gcli;
    precinct_data_t *precincts;  // 2592=40*MAX_PACKETS(64)
    bool seg_empty[52];
    int *worker_buffs;
    idwt_state_t idwt_state[XS_MAX_IMAGE_COMPONENTS];
    int *idwt_b1_v2;
    int *idwt_b2_v2;

    stage1_data(uint32_t line_stride)
    {
        uint32_t line_stride_4k = ((line_stride >> 7) + 31) >> 5 << 12;
        buf.resize(line_stride_4k + sizeof(int32_t)*7*line_stride_4k);
        gcli = buf.data();
        worker_buffs = (int32_t *)(gcli + line_stride_4k);
        idwt_b1_v2 = worker_buffs + 5*line_stride_4k;
        idwt_b2_v2 = idwt_b1_v2 + line_stride_4k;
        precs.resize(0xA20); // 2592=40*MAX_PACKETS(64)
        precincts = precs.data();
    }
private:
    std::vector<uint8_t> buf;
    std::vector<precinct_data_t> precs;
};

const uint8_t predict_lut_gtli[8192] =
{
    0  , 1  , 2  , 3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 1  , 0  , 2  , 3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 ,
    16 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 2  , 1  , 3  , 0  , 4  , 5  , 6  , 7  ,
    8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    3  , 2  , 4  , 1  , 5  , 0  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 4  , 3  , 5  , 2  , 6  , 1  , 7  , 0  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 ,
    16 , 17 , 18 , 19 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 5  , 4  , 6  , 3  , 7  , 2  , 8  , 1  ,
    9  , 0  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 20 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    6  , 5  , 7  , 4  , 8  , 3  , 9  , 2  , 10 , 1  , 11 , 0  , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 20 , 21 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 7  , 6  , 8  , 5  , 9  , 4  , 10 , 3  , 11 , 2  , 12 , 1  , 13 , 0  , 14 , 15 ,
    16 , 17 , 18 , 19 , 20 , 21 , 22 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 8  , 7  , 9  , 6  , 10 , 5  , 11 , 4  ,
    12 , 3  , 13 , 2  , 14 , 1  , 15 , 0  , 16 , 17 , 18 , 19 , 20 , 21 , 22 , 23 , 255, 255, 255, 255, 255, 255, 255, 255,
    9  , 8  , 10 , 7  , 11 , 6  , 12 , 5  , 13 , 4  , 14 , 3  , 15 , 2  , 16 , 1  , 17 , 0  , 18 , 19 , 20 , 21 , 22 , 23 ,
    24 , 255, 255, 255, 255, 255, 255, 255, 10 , 9  , 11 , 8  , 12 , 7  , 13 , 6  , 14 , 5  , 15 , 4  , 16 , 3  , 17 , 2  ,
    18 , 1  , 19 , 0  , 20 , 21 , 22 , 23 , 24 , 25 , 255, 255, 255, 255, 255, 255, 11 , 10 , 12 , 9  , 13 , 8  , 14 , 7  ,
    15 , 6  , 16 , 5  , 17 , 4  , 18 , 3  , 19 , 2  , 20 , 1  , 21 , 0  , 22 , 23 , 24 , 25 , 26 , 255, 255, 255, 255, 255,
    12 , 11 , 13 , 10 , 14 , 9  , 15 , 8  , 16 , 7  , 17 , 6  , 18 , 5  , 19 , 4  , 20 , 3  , 21 , 2  , 22 , 1  , 23 , 0  ,
    24 , 25 , 26 , 27 , 255, 255, 255, 255, 13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  , 17 , 8  , 18 , 7  , 19 , 6  , 20 , 5  ,
    21 , 4  , 22 , 3  , 23 , 2  , 24 , 1  , 25 , 0  , 26 , 27 , 28 , 255, 255, 255, 14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 ,
    18 , 9  , 19 , 8  , 20 , 7  , 21 , 6  , 22 , 5  , 23 , 4  , 24 , 3  , 25 , 2  , 26 , 1  , 27 , 0  , 28 , 29 , 255, 255,
    15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 , 19 , 10 , 20 , 9  , 21 , 8  , 22 , 7  , 23 , 6  , 24 , 5  , 25 , 4  , 26 , 3  ,
    27 , 2  , 28 , 1  , 29 , 0  , 30 , 255, 1  , 2  , 3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 1  , 2  , 3  , 4  , 5  , 6  , 7  , 8  ,
    9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    2  , 1  , 3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 3  , 2  , 4  , 1  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 ,
    17 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 4  , 3  , 5  , 2  , 6  , 1  , 7  , 8  ,
    9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    5  , 4  , 6  , 3  , 7  , 2  , 8  , 1  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 6  , 5  , 7  , 4  , 8  , 3  , 9  , 2  , 10 , 1  , 11 , 12 , 13 , 14 , 15 , 16 ,
    17 , 18 , 19 , 20 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7  , 6  , 8  , 5  , 9  , 4  , 10 , 3  ,
    11 , 2  , 12 , 1  , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 20 , 21 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    8  , 7  , 9  , 6  , 10 , 5  , 11 , 4  , 12 , 3  , 13 , 2  , 14 , 1  , 15 , 16 , 17 , 18 , 19 , 20 , 21 , 22 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 9  , 8  , 10 , 7  , 11 , 6  , 12 , 5  , 13 , 4  , 14 , 3  , 15 , 2  , 16 , 1  ,
    17 , 18 , 19 , 20 , 21 , 22 , 23 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 10 , 9  , 11 , 8  , 12 , 7  , 13 , 6  ,
    14 , 5  , 15 , 4  , 16 , 3  , 17 , 2  , 18 , 1  , 19 , 20 , 21 , 22 , 23 , 24 , 255, 255, 255, 255, 255, 255, 255, 255,
    11 , 10 , 12 , 9  , 13 , 8  , 14 , 7  , 15 , 6  , 16 , 5  , 17 , 4  , 18 , 3  , 19 , 2  , 20 , 1  , 21 , 22 , 23 , 24 ,
    25 , 255, 255, 255, 255, 255, 255, 255, 12 , 11 , 13 , 10 , 14 , 9  , 15 , 8  , 16 , 7  , 17 , 6  , 18 , 5  , 19 , 4  ,
    20 , 3  , 21 , 2  , 22 , 1  , 23 , 24 , 25 , 26 , 255, 255, 255, 255, 255, 255, 13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  ,
    17 , 8  , 18 , 7  , 19 , 6  , 20 , 5  , 21 , 4  , 22 , 3  , 23 , 2  , 24 , 1  , 25 , 26 , 27 , 255, 255, 255, 255, 255,
    14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 , 18 , 9  , 19 , 8  , 20 , 7  , 21 , 6  , 22 , 5  , 23 , 4  , 24 , 3  , 25 , 2  ,
    26 , 1  , 27 , 28 , 255, 255, 255, 255, 15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 , 19 , 10 , 20 , 9  , 21 , 8  , 22 , 7  ,
    23 , 6  , 24 , 5  , 25 , 4  , 26 , 3  , 27 , 2  , 28 , 1  , 29 , 255, 255, 255, 2  , 3  , 4  , 5  , 6  , 7  , 8  , 9  ,
    10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    2  , 3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 2  , 3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3  , 2  , 4  , 5  , 6  , 7  , 8  , 9  ,
    10 , 11 , 12 , 13 , 14 , 15 , 16 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    4  , 3  , 5  , 2  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 5  , 4  , 6  , 3  , 7  , 2  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 ,
    18 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 6  , 5  , 7  , 4  , 8  , 3  , 9  , 2  ,
    10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    7  , 6  , 8  , 5  , 9  , 4  , 10 , 3  , 11 , 2  , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 20 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 8  , 7  , 9  , 6  , 10 , 5  , 11 , 4  , 12 , 3  , 13 , 2  , 14 , 15 , 16 , 17 ,
    18 , 19 , 20 , 21 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 9  , 8  , 10 , 7  , 11 , 6  , 12 , 5  ,
    13 , 4  , 14 , 3  , 15 , 2  , 16 , 17 , 18 , 19 , 20 , 21 , 22 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    10 , 9  , 11 , 8  , 12 , 7  , 13 , 6  , 14 , 5  , 15 , 4  , 16 , 3  , 17 , 2  , 18 , 19 , 20 , 21 , 22 , 23 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 11 , 10 , 12 , 9  , 13 , 8  , 14 , 7  , 15 , 6  , 16 , 5  , 17 , 4  , 18 , 3  ,
    19 , 2  , 20 , 21 , 22 , 23 , 24 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 12 , 11 , 13 , 10 , 14 , 9  , 15 , 8  ,
    16 , 7  , 17 , 6  , 18 , 5  , 19 , 4  , 20 , 3  , 21 , 2  , 22 , 23 , 24 , 25 , 255, 255, 255, 255, 255, 255, 255, 255,
    13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  , 17 , 8  , 18 , 7  , 19 , 6  , 20 , 5  , 21 , 4  , 22 , 3  , 23 , 2  , 24 , 25 ,
    26 , 255, 255, 255, 255, 255, 255, 255, 14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 , 18 , 9  , 19 , 8  , 20 , 7  , 21 , 6  ,
    22 , 5  , 23 , 4  , 24 , 3  , 25 , 2  , 26 , 27 , 255, 255, 255, 255, 255, 255, 15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 ,
    19 , 10 , 20 , 9  , 21 , 8  , 22 , 7  , 23 , 6  , 24 , 5  , 25 , 4  , 26 , 3  , 27 , 2  , 28 , 255, 255, 255, 255, 255,
    3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 ,
    11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    3  , 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 4  , 3  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 5  , 4  , 6  , 3  , 7  , 8  , 9  , 10 ,
    11 , 12 , 13 , 14 , 15 , 16 , 17 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    6  , 5  , 7  , 4  , 8  , 3  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 7  , 6  , 8  , 5  , 9  , 4  , 10 , 3  , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 ,
    19 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 8  , 7  , 9  , 6  , 10 , 5  , 11 , 4  ,
    12 , 3  , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 20 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    9  , 8  , 10 , 7  , 11 , 6  , 12 , 5  , 13 , 4  , 14 , 3  , 15 , 16 , 17 , 18 , 19 , 20 , 21 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 10 , 9  , 11 , 8  , 12 , 7  , 13 , 6  , 14 , 5  , 15 , 4  , 16 , 3  , 17 , 18 ,
    19 , 20 , 21 , 22 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 11 , 10 , 12 , 9  , 13 , 8  , 14 , 7  ,
    15 , 6  , 16 , 5  , 17 , 4  , 18 , 3  , 19 , 20 , 21 , 22 , 23 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    12 , 11 , 13 , 10 , 14 , 9  , 15 , 8  , 16 , 7  , 17 , 6  , 18 , 5  , 19 , 4  , 20 , 3  , 21 , 22 , 23 , 24 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  , 17 , 8  , 18 , 7  , 19 , 6  , 20 , 5  ,
    21 , 4  , 22 , 3  , 23 , 24 , 25 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 ,
    18 , 9  , 19 , 8  , 20 , 7  , 21 , 6  , 22 , 5  , 23 , 4  , 24 , 3  , 25 , 26 , 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 , 19 , 10 , 20 , 9  , 21 , 8  , 22 , 7  , 23 , 6  , 24 , 5  , 25 , 4  , 26 , 3  ,
    27 , 255, 255, 255, 255, 255, 255, 255, 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 ,
    12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 4  , 5  , 6  , 7  , 8  , 9  , 10 , 11 ,
    12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    5  , 4  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 6  , 5  , 7  , 4  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7  , 6  , 8  , 5  , 9  , 4  , 10 , 11 ,
    12 , 13 , 14 , 15 , 16 , 17 , 18 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    8  , 7  , 9  , 6  , 10 , 5  , 11 , 4  , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 19 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 9  , 8  , 10 , 7  , 11 , 6  , 12 , 5  , 13 , 4  , 14 , 15 , 16 , 17 , 18 , 19 ,
    20 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10 , 9  , 11 , 8  , 12 , 7  , 13 , 6  ,
    14 , 5  , 15 , 4  , 16 , 17 , 18 , 19 , 20 , 21 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    11 , 10 , 12 , 9  , 13 , 8  , 14 , 7  , 15 , 6  , 16 , 5  , 17 , 4  , 18 , 19 , 20 , 21 , 22 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 12 , 11 , 13 , 10 , 14 , 9  , 15 , 8  , 16 , 7  , 17 , 6  , 18 , 5  , 19 , 4  ,
    20 , 21 , 22 , 23 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  ,
    17 , 8  , 18 , 7  , 19 , 6  , 20 , 5  , 21 , 4  , 22 , 23 , 24 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 , 18 , 9  , 19 , 8  , 20 , 7  , 21 , 6  , 22 , 5  , 23 , 4  , 24 , 25 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 , 19 , 10 , 20 , 9  , 21 , 8  , 22 , 7  ,
    23 , 6  , 24 , 5  , 25 , 4  , 26 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 ,
    13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 ,
    13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 5  , 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 6  , 5  , 7  , 8  , 9  , 10 , 11 , 12 ,
    13 , 14 , 15 , 16 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    7  , 6  , 8  , 5  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 8  , 7  , 9  , 6  , 10 , 5  , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 9  , 8  , 10 , 7  , 11 , 6  , 12 , 5  ,
    13 , 14 , 15 , 16 , 17 , 18 , 19 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    10 , 9  , 11 , 8  , 12 , 7  , 13 , 6  , 14 , 5  , 15 , 16 , 17 , 18 , 19 , 20 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 11 , 10 , 12 , 9  , 13 , 8  , 14 , 7  , 15 , 6  , 16 , 5  , 17 , 18 , 19 , 20 ,
    21 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 12 , 11 , 13 , 10 , 14 , 9  , 15 , 8  ,
    16 , 7  , 17 , 6  , 18 , 5  , 19 , 20 , 21 , 22 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  , 17 , 8  , 18 , 7  , 19 , 6  , 20 , 5  , 21 , 22 , 23 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 , 18 , 9  , 19 , 8  , 20 , 7  , 21 , 6  ,
    22 , 5  , 23 , 24 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 ,
    19 , 10 , 20 , 9  , 21 , 8  , 22 , 7  , 23 , 6  , 24 , 5  , 25 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 ,
    14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 ,
    14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    6  , 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 7  , 6  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 8  , 7  , 9  , 6  , 10 , 11 , 12 , 13 ,
    14 , 15 , 16 , 17 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    9  , 8  , 10 , 7  , 11 , 6  , 12 , 13 , 14 , 15 , 16 , 17 , 18 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 10 , 9  , 11 , 8  , 12 , 7  , 13 , 6  , 14 , 15 , 16 , 17 , 18 , 19 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 11 , 10 , 12 , 9  , 13 , 8  , 14 , 7  ,
    15 , 6  , 16 , 17 , 18 , 19 , 20 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    12 , 11 , 13 , 10 , 14 , 9  , 15 , 8  , 16 , 7  , 17 , 6  , 18 , 19 , 20 , 21 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  , 17 , 8  , 18 , 7  , 19 , 6  , 20 , 21 ,
    22 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 ,
    18 , 9  , 19 , 8  , 20 , 7  , 21 , 6  , 22 , 23 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 , 19 , 10 , 20 , 9  , 21 , 8  , 22 , 7  , 23 , 6  , 24 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 ,
    15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 ,
    15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 7  , 8  , 9  , 10 , 11 , 12 , 13 , 14 ,
    15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    8  , 7  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 16 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 9  , 8  , 10 , 7  , 11 , 12 , 13 , 14 , 15 , 16 , 17 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10 , 9  , 11 , 8  , 12 , 7  , 13 , 14 ,
    15 , 16 , 17 , 18 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    11 , 10 , 12 , 9  , 13 , 8  , 14 , 7  , 15 , 16 , 17 , 18 , 19 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 12 , 11 , 13 , 10 , 14 , 9  , 15 , 8  , 16 , 7  , 17 , 18 , 19 , 20 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  ,
    17 , 8  , 18 , 7  , 19 , 20 , 21 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 , 18 , 9  , 19 , 8  , 20 , 7  , 21 , 22 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 , 19 , 10 , 20 , 9  , 21 , 8  , 22 , 7  ,
    23 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 ,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 ,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 ,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 8  , 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 9  , 8  , 10 , 11 , 12 , 13 , 14 , 15 ,
    16 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    10 , 9  , 11 , 8  , 12 , 13 , 14 , 15 , 16 , 17 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 11 , 10 , 12 , 9  , 13 , 8  , 14 , 15 , 16 , 17 , 18 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 12 , 11 , 13 , 10 , 14 , 9  , 15 , 8  ,
    16 , 17 , 18 , 19 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  , 17 , 8  , 18 , 19 , 20 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 , 18 , 9  , 19 , 8  , 20 , 21 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 ,
    19 , 10 , 20 , 9  , 21 , 8  , 22 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 9  , 10 , 11 , 12 , 13 , 14 , 15 , 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    9  , 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 10 , 9  , 11 , 12 , 13 , 14 , 15 , 16 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 11 , 10 , 12 , 9  , 13 , 14 , 15 , 16 ,
    17 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    12 , 11 , 13 , 10 , 14 , 9  , 15 , 16 , 17 , 18 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 13 , 12 , 14 , 11 , 15 , 10 , 16 , 9  , 17 , 18 , 19 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 ,
    18 , 9  , 19 , 20 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 , 19 , 10 , 20 , 9  , 21 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10 , 11 , 12 , 13 , 14 , 15 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10 , 11 , 12 , 13 , 14 , 15 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10 , 11 , 12 , 13 , 14 , 15 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 10 , 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 10 , 11 , 12 , 13 , 14 , 15 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    11 , 10 , 12 , 13 , 14 , 15 , 16 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 12 , 11 , 13 , 10 , 14 , 15 , 16 , 17 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 13 , 12 , 14 , 11 , 15 , 10 , 16 , 17 ,
    18 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    14 , 13 , 15 , 12 , 16 , 11 , 17 , 10 , 18 , 19 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 , 19 , 10 , 20 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 11 , 12 , 13 , 14 , 15 , 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 11 , 12 , 13 , 14 , 15 , 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 11 , 12 , 13 , 14 , 15 , 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 11 , 12 , 13 , 14 , 15 , 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 11 , 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 12 , 11 , 13 , 14 , 15 , 16 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    13 , 12 , 14 , 11 , 15 , 16 , 17 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 14 , 13 , 15 , 12 , 16 , 11 , 17 , 18 , 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15 , 14 , 16 , 13 , 17 , 12 , 18 , 11 ,
    19 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 12 , 13 , 14 , 15 , 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 12 , 13 , 14 , 15 , 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 12 , 13 , 14 , 15 , 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 12 , 13 , 14 , 15 , 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    12 , 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 13 , 12 , 14 , 15 , 16 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 14 , 13 , 15 , 12 , 16 , 17 , 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 14 , 16 , 13 , 17 , 12 , 18 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 13 , 14 , 15 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    14 , 13 , 15 , 16 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 15 , 14 , 16 , 13 , 17 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 14 , 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15 , 14 , 16 , 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 15 , 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    15 , 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255, 255,
    255, 255, 255, 255, 255, 255, 255, 255
};


static libraw_inline int32_t get_line_stride(uint32_t width)
{
    return (width + 1) >> 1;
}

static libraw_inline int get_image_width(nikonhe_decoder *decoder)
{
    return 2 * decoder->img.w_pix;
}

static libraw_inline int get_image_height(nikonhe_decoder *decoder)
{
    return 2 * decoder->img.h_pix - decoder->img.h_pad_pix;
}

static libraw_inline uint32_t precinct_header_size(const nikonhe_image *img)
{
    return (2 * img->num_sb + 40 + 7) >> 3;
}

static libraw_inline int img_width(const nikonhe_image *img, int comp)
{
    return comp && img->is_422 ? (img->w_pix + 1) / 2 : img->w_pix;
}

err_code_t nikonhe_init_image_data(nikonhe_image *img)
{
    uint32_t width[4][3][6];
    int8_t h_lvl_max_per_v_lvl[3];

    uint32_t nb_seg_in_pkt = 0;
    uint32_t nb_grp_in_pkt = 0;
    int max_res = img->v_lvl - 1;
    int n_semi_comp_width_grp = 0;

    // reset all working data
    memset(h_lvl_max_per_v_lvl, 0, sizeof(h_lvl_max_per_v_lvl));
    memset(img->seg_pkt, -1, sizeof(img->seg_pkt));
    memset(img->seg_sb,  -1, sizeof(img->seg_sb));
    memset(img->seg_pv,  -1, sizeof(img->seg_pv));
    memset(img->pos_seg, -1, sizeof(img->pos_seg));
    memset(img->seg_grp, 0, sizeof(img->seg_grp));
    memset(img->sp_seg, -1, sizeof(img->sp_seg));
    memset(img->sp_chunks, 0, sizeof(img->sp_chunks));
    memset(img->sp_sb_order, -1, sizeof(img->sp_sb_order));
    memset(img->sp_dual, -1, sizeof(img->sp_dual));
    memset(img->seg_res, -1, sizeof(img->seg_res));
    memset(img->sp_res, -1, sizeof(img->sp_res));
    memset(img->semi_comp_chunks, 0, sizeof(img->semi_comp_chunks));
    memset(img->sb_seg, -1, sizeof(img->sb_seg));

    img->pkt_grp = 0;
    img->nb_pkt = 0;
    img->num_sb = 0;
    img->nb_seg = 0;
    img->line_stride = 0;
    memset(width, 0, sizeof(width));
    for (int comp = 0; comp < img->n_comp; ++comp)
    {
        int width_comp = img_width(img, comp);
        if (img->skip_decomp[comp])
        {
            for (int v_lvl = 0; v_lvl < img->v_lvl; ++v_lvl)
            {
                for (int h_lvl = h_lvl_max_per_v_lvl[v_lvl]; h_lvl > 0; --h_lvl)
                    width[comp][v_lvl][h_lvl] = 0;
            }
            width[comp][0][0] = (unsigned int)(width_comp + 3) >> 2;
            width[comp][1][0] = (unsigned int)(width_comp + 3) >> 2;
            img->semi_comp_chunks[comp] = (((32 * ((width[comp][0][0] + 7) >> 3)) >> 1) + 63) >> 6 << 6;
        }
        else
        {
            for (int v_lvl = 0; v_lvl < img->v_lvl; ++v_lvl)
            {
                unsigned int w = width_comp;
                if (!v_lvl)
                    h_lvl_max_per_v_lvl[v_lvl] = img->h_lvl - 1;
                else
                    h_lvl_max_per_v_lvl[v_lvl] = img->v_lvl - v_lvl;
                for (int h_lvl = h_lvl_max_per_v_lvl[v_lvl]; h_lvl > 0; --h_lvl)
                {
                    width[comp][v_lvl][h_lvl] = ((w >> 1) + 3) >> 2;
                    w = (w + 1) >> 1;
                }
                width[comp][v_lvl][0] = (w + 3) >> 2;
                img->odd_ofs[comp][v_lvl][h_lvl_max_per_v_lvl[v_lvl]] = 32 * ((width[comp][v_lvl][0] + 7) >> 3);
                for (int h_lvl = h_lvl_max_per_v_lvl[v_lvl]; h_lvl > 0; --h_lvl)
		    img->odd_ofs[comp][v_lvl][h_lvl - 1] =
                        32 * ((width[comp][v_lvl][h_lvl_max_per_v_lvl[v_lvl] - h_lvl + 1]
                               + 7) >> 3)
                        + img->odd_ofs[comp][v_lvl][h_lvl];
            }
            unsigned int semi_comp_width = 0;
            for (int h_lvl = 0; h_lvl < h_lvl_max_per_v_lvl[0]; ++h_lvl)
                semi_comp_width += 32 * ((width[comp][0][h_lvl] + 7) >> 3);
            img->semi_comp_chunks[comp] = (semi_comp_width + 63) >> 6 << 6;
        }
        img->line_stride += 2 * img->semi_comp_chunks[comp];
        n_semi_comp_width_grp += img->semi_comp_chunks[comp] >> 2;
    }
    img->pkt_grp = 2 * n_semi_comp_width_grp * img->v_lines;
    if (img->ppoc == NIKONHE_PPOC_RPBC)
    {
        for (int res = 0; res <= max_res; ++res)
        {
            for (int line = 0; ; ++line)
            {
                if (line >= (res >= 1 ? 1 << (res - 1) : 1))
                    break;
                for (int v_lvl = 0; v_lvl <= res; v_lvl += (res ? res : 1))
                {
                    int h_lvl_from = !res || v_lvl ? 0 : res + img->h_lvl - img->v_lvl;
                    int h_lvl_to = v_lvl ? 1 : res + img->h_lvl - img->v_lvl;
                    for (int h_lvl = h_lvl_from; h_lvl <= h_lvl_to; ++h_lvl)
                    {
                        int line_idx = v_lvl
                                        ? line + (1 << (v_lvl - 1))
                                        : line;
                        int col_idx = !line || v_lvl
                                        ? h_lvl
                                        : h_lvl - (img->h_lvl - img->v_lvl);
                        for (int comp = 0; comp < img->n_comp; ++comp)
                        {
                            int sb = h_lvl + 6 * (v_lvl + 3 * comp);
                            int width_group = width[comp][v_lvl][h_lvl];
                            img->pos_seg[comp][line_idx][col_idx] = img->nb_seg;
                            img->seg_res[img->nb_seg] = res;
                            img->seg_pkt[img->nb_seg] = img->nb_pkt;
                            img->seg_sb[img->nb_seg] = sb;
                            img->seg_grp[img->nb_seg].len_grp = width_group;
                            nb_grp_in_pkt += width_group;
                            img->sb_seg[sb][line] = img->nb_seg;
                            int dualIdx = img->nb_pkt;
                            if (line <= 0)
                            {
                                img->seg_pv[img->nb_seg] = img->nb_seg;
                            }
                            else
                            {
                                img->seg_pv[img->nb_seg] = img->nb_seg - 3 * img->n_comp;
                                img->seg_pv[img->seg_pv[img->nb_seg]] = img->nb_seg;
                                img->sp_dual[img->nb_pkt] = img->nb_pkt - 3;
                                dualIdx = img->sp_dual[img->nb_pkt];
                            }
                            img->sp_dual[dualIdx] = img->nb_pkt;
                            img->sp_seg[img->nb_pkt][nb_seg_in_pkt] = img->nb_seg;
                            img->sp_seg_size[img->nb_pkt] = nb_seg_in_pkt + 1;
                            if (!line)
                                img->sp_sb_order[img->num_sb++] = sb;
                            ++nb_seg_in_pkt;
                            ++img->nb_seg;
                        }
                        if (res || h_lvl == img->h_lvl - img->v_lvl)
                        {
                            img->sp_res[img->nb_pkt] = res;
                            img->sp_chunks[img->nb_pkt] = nb_grp_in_pkt;
                            nb_seg_in_pkt = 0;
                            nb_grp_in_pkt = 0;
                            ++img->nb_pkt;
                        }
                    }
                }
            }
        }
        int swapped_buffer = img->v_lines == 4;
        for (int line = 0; line < img->v_lines; ++line)
        {
            int h_lvl_max_line = h_lvl_max_per_v_lvl[line <= img->v_lvl - 1
                                                        ? line
                                                        : img->v_lvl - 1];
            int line_offset_grp = 2 * n_semi_comp_width_grp * line;
            for (int i = 0; i <= swapped_buffer; ++i)
            {
                int h_lvl_from = swapped_buffer && i
                                    ? h_lvl_max_line
                                    : 0;
                int h_lvl_to = !swapped_buffer || i
                                ? h_lvl_max_line
                                : h_lvl_max_line - 1;
                int group_ofs = n_semi_comp_width_grp * i + line_offset_grp;
                for (int comp = 0; comp < img->n_comp; ++comp)
                {
                    int group = group_ofs;
                    for (int h_lvl = h_lvl_from; h_lvl <= h_lvl_to; ++h_lvl)
                    {
                        int seg = img->pos_seg[comp][line][h_lvl];
                        int width_group = img->seg_grp[img->pos_seg[comp][line][h_lvl]].len_grp;
                        img->seg_grp[img->pos_seg[comp][line][h_lvl]].ofs_grp = group;
                        img->seg_grp[seg].ofs_coef = 4 * (group - line_offset_grp) + 8 * line_offset_grp;
                        group += 8 * ((unsigned int)(width_group + 7) >> 3);
                    }
                    if (swapped_buffer)
                        group_ofs += img->semi_comp_chunks[comp] >> 2;
                    else
                        group_ofs += img->semi_comp_chunks[comp] >> 1;
                }
            }
        }
    }
    else if (img->ppoc != NIKONHE_PPOC_VCGH && img->ppoc != NIKONHE_PPOC_VGCH)
        return NIKONHE_GENERIC_ERROR;
    else if (img->v_lvl > 2)
        return NIKONHE_GENERIC_ERROR;
    else
        for (int v_lvl = 0; v_lvl < img->v_lvl; ++v_lvl)
        {
            int line_offset_grp = 2 * n_semi_comp_width_grp * v_lvl;
            int group_ofs = line_offset_grp;
            for (int comp = 0; comp < img->n_comp; ++comp)
            {
                int group = group_ofs;
                int h_lvl_max_1 = !v_lvl ? img->h_lvl : 2;
                if (img->skip_decomp[comp])
                    h_lvl_max_1 = 1;
                for (int h_lvl = 0; h_lvl < h_lvl_max_1; ++h_lvl)
                {
                    int sb = h_lvl + 6 * (v_lvl + 3 * comp);
                    if (img->skip_decomp[comp])
                        sb = h_lvl + 18 * comp;
                    int width_group = width[comp][v_lvl][h_lvl];
                    img->pos_seg[comp][v_lvl][h_lvl] = img->nb_seg;
                    img->seg_res[img->nb_seg] = (v_lvl || h_lvl == h_lvl_max_1 - 1); // bool value - 0,1
                    img->seg_pkt[img->nb_seg] = img->nb_pkt;
                    img->seg_sb[img->nb_seg] = sb;
                    img->seg_grp[img->nb_seg].ofs_grp = group;
                    img->seg_grp[img->nb_seg].ofs_coef = 4 * (group - line_offset_grp) + 8 * line_offset_grp;
                    img->seg_grp[img->nb_seg].len_grp = width_group;
                    nb_grp_in_pkt += width_group;
                    group += 8 * ((unsigned int)(width_group + 7) >> 3);
                    if (img->skip_decomp[comp] && v_lvl > 0)
                        img->sb_seg[sb][v_lvl] = img->nb_seg;
                    else
                        img->sb_seg[sb][0] = img->nb_seg;
                    if (img->skip_decomp[comp])
                    {
                        if (v_lvl)
                            img->seg_pv[img->nb_seg] = img->nb_seg - img->h_lvl - 5;
                        else
                           img->seg_pv[img->nb_seg] = img->h_lvl + img->nb_seg + 5;
                    }
                    else
                    {
                        img->seg_pv[img->nb_seg] = img->nb_seg;
                    }
                    img->sp_dual[img->nb_pkt] = img->nb_pkt;
                    img->sp_seg[img->nb_pkt][nb_seg_in_pkt] = img->nb_seg;
                    img->sp_seg_size[img->nb_pkt] = nb_seg_in_pkt + 1;
                    ++img->nb_seg;
                    if (!img->skip_decomp[comp] || v_lvl <= 0)
                        img->sp_sb_order[img->num_sb++] = sb;
                    ++nb_seg_in_pkt;
                }
                group_ofs += (2 * img->semi_comp_chunks[comp]) >> 2;
                if (img->ppoc == NIKONHE_PPOC_VCGH)
                {
                    img->sp_res[img->nb_pkt] = v_lvl;
                    img->sp_chunks[img->nb_pkt] = nb_grp_in_pkt;
                    nb_seg_in_pkt = 0;
                    nb_grp_in_pkt = 0;
                    ++img->nb_pkt;
                }
            }
            if (img->ppoc == NIKONHE_PPOC_VGCH)
            {
                img->sp_res[img->nb_pkt] = v_lvl;
                img->sp_chunks[img->nb_pkt] = nb_grp_in_pkt;
                nb_seg_in_pkt = 0;
                nb_grp_in_pkt = 0;
                ++img->nb_pkt;
            }
        }

    if (img->num_sb > 0x48 || img->nb_seg > 0x34 || img->nb_pkt > 0xA)
        return NIKONHE_GENERIC_ERROR;
    for (int seg = 0; seg < img->nb_seg; ++seg)
        img->seg_sig_size[seg] = (unsigned int)(img->seg_grp[seg].len_grp + 7) >> 3;

    return NIKONHE_SUCCESS;
}

void jpeg_xs_set_compression_options(
    nikonhe_image *img,
    const jpegxs_pih_t *picture_data)
{
    img->h_lvl = picture_data->n_hor_wavelet_transform + 1;
    img->v_lvl = picture_data->n_ver_wavelet_transform + 1;
    img->v_lines = img->v_lvl >= 1 ? 1 << (img->v_lvl - 1) : 1; // pixel lines per precinct
    img->ppoc = (bands_progression_order_t)picture_data->progr_order_bands_precinct;
    img->input_scale = picture_data->nominal_precision_wavelet;
    img->prequant = picture_data->fractional_bits_wavelet;
    img->is_uniform_q = picture_data->quantizer_type & 1;
    img->signs_separate = picture_data->sign_handling_strategy & 1;
    img->is_run_mode_zero_coeff = picture_data->run_mode & 1;
    img->slh_pix = be16(picture_data->height_slice) << (img->v_lvl - 1); // slice height in pixels
}

int jpeg_xs_parse_file_header(nikonhe_image *img, const void *hdr, int64_t len)
{
    uint8_t *data = (uint8_t *)hdr;
    bool ipx_hdr = false;
    int64_t index = 0;
    int64_t extra_sgmt_sz = 0;
    nikonhe_capabilities_t *caps = 0;
    bitstream_reader bsr;
    uint8_t zero_vector[1024];

    // SOC
    if (len < 2)
        return NIKONHE_GENERIC_ERROR;
    uint16_t soc = be16(*(uint16_t *)&data[index]);
    index += 2;
    if (soc != XS_MARKER_SOC)
        return NIKONHE_GENERIC_ERROR;
    if (index + 2 > len)
        return NIKONHE_GENERIC_ERROR;

    // CAP parsing
    uint16_t cap = be16(*(uint16_t *)&data[index]);
    index += 2;
    if (cap != XS_MARKER_CAP)
        return NIKONHE_GENERIC_ERROR;
    if (index + 2 > len)
        return NIKONHE_GENERIC_ERROR;

    uint16_t lcap = be16(*(uint16_t *)&data[index]);   // CAP length
    index += 2;
    if (lcap <= 2)
    {
        if (lcap < 2)
            return NIKONHE_GENERIC_ERROR;
    }
    else
    {
        memset(zero_vector, 0, sizeof(zero_vector));
        if (lcap + index - 2 > len)
            return NIKONHE_GENERIC_ERROR;
        if (memcmp(&data[index], zero_vector, lcap - 2))
        {
            if (lcap - 2 < 0x10)
                return NIKONHE_GENERIC_ERROR;
            if (index + 16 > len || index + 18 > len || index + 32 > len)
                return NIKONHE_GENERIC_ERROR;
            static const char contIntopix[] = "CONTACT_INTOPIX_";
            if (memcmp(&data[index], contIntopix, sizeof(contIntopix)-1))
                return NIKONHE_GENERIC_ERROR;
            caps = (nikonhe_capabilities_t *)&data[index + 16];
            if (caps->unused_bits != 0 || memcmp(&data[index + 18], zero_vector, 0xE))
                return NIKONHE_GENERIC_ERROR;
            ipx_hdr = 1;
        }
    }
    index += lcap - 2;
    if (index + 2 > len)
        return NIKONHE_GENERIC_ERROR;

    // PIH parsing
    uint16_t pih = be16(*(uint16_t *)&data[index]);
    index += 2;
    if (pih != XS_MARKER_PIH)
        return NIKONHE_GENERIC_ERROR;
    if (index + 2 > len)
        return NIKONHE_GENERIC_ERROR;
    uint16_t lpih = be16(*(uint16_t *)&data[index]);  // PIH length
    index += 2;
    if (index + 24 > len)
        return NIKONHE_GENERIC_ERROR;
    const jpegxs_pih_t *picture_data = (const jpegxs_pih_t *)&data[index];
    index += 24;
    if (picture_data->width_precinct
        || picture_data->n_coef_per_code_group != 4
        || picture_data->n_code_group_per_sig_group != 8
        || picture_data->bits_bitplane_raw != 4
        || picture_data->colour_transform > 1
        || picture_data->slice_coding_mode != 0
        || picture_data->sign_handling_strategy > 1
        || picture_data->quantizer_type > 1
        || picture_data->nominal_precision_wavelet > 0x14
        || picture_data->run_mode > 1)
    {
        return NIKONHE_GENERIC_ERROR;
    }
    img->n_comp = picture_data->n_components;
    img->total_bytes = be32(picture_data->codestream_size);
    img->w_pix = be16(picture_data->width_img);
    img->h_pix = be16(picture_data->height_img);
    jpeg_xs_set_compression_options(img, picture_data);
    int qux_dwt53_bayer = 0;
    int qux_ycbcr_bayer = 0;
    int diff_vh_lvls_per_comp = 0;
    if (ipx_hdr)
    {
        // Extended IntoPIX header - non standard JpegXS
        bsr.init(&data[index], len - index);
        if (caps->nikonhe_cap_long_pkt_hdr)
            img->is_nikonhe_long_packet_hdr = bsr.read(2) & 1;
        if (caps->nikonhe_cap_no_raw_mode_gcli)
            bsr.read(2);   // ignored
        if (caps->nikonhe_cap_interframe)
        {
            return NIKONHE_GENERIC_ERROR;
        }
        if (caps->nikonhe_cap_b_gains)
            bsr.read(1);   // ignored
        if (caps->nikonhe_cap_gamma_transform)
        {
            img->gamma_data.enabled = bsr.read(4);
            raw_gamma_type_t gamma_type = (raw_gamma_type_t)bsr.read(4);
            if (!img->gamma_data.enabled)
                gamma_type = raw_gamma_type_none;
            if (img->gamma_data.enabled > 1
                || gamma_type < raw_gamma_type_none
                || gamma_type > raw_gamma_type_linear)
            {
                return NIKONHE_GENERIC_ERROR;
            }
            img->gamma_data.in_bitdepth  = bsr.read(8);
            img->gamma_data.out_bitdepth = bsr.read(8);
            if (gamma_type == raw_gamma_type_curve_inversion ||
                gamma_type == raw_gamma_type_linear)
            {
                int32_t gamma_offset_16 =
                    bsr.read(13) >>
                    (img->gamma_data.out_bitdepth - img->gamma_data.in_bitdepth) <<
                    (img->gamma_data.out_bitdepth - img->gamma_data.in_bitdepth);
                uint32_t offset_mode = bsr.read(2);
                uint32_t r_val = bsr.read(18);
                uint32_t r_flip = bsr.read(18);
                uint32_t offset_sqrt = bsr.read(16);
                int32_t pregamma_offset = 0;
                switch (offset_mode)
                {
                case 0:
                    gamma_offset_16 = 0;
                    gamma_type = raw_gamma_type_linear;
                    break;
                case 1:
                    gamma_type = raw_gamma_type_curve_inversion;
                    break;
                case 2:
                    gamma_type = raw_gamma_type_linear;
                    break;
                case 3:
                    pregamma_offset = gamma_offset_16;
                    gamma_offset_16 = 0;
                    r_val = 0x10000;
                    r_flip = 0x10000;
                    offset_sqrt = 0;
                    gamma_type = raw_gamma_type_shifted;
                    break;
                default:
                    return NIKONHE_GENERIC_ERROR;
                }
                img->gamma_data.gamma_type = gamma_type;
                img->gamma_data.gamma_value = 2.0;
                img->gamma_data.offset_16 = gamma_offset_16;
                img->gamma_data.offset_sqrt = offset_sqrt;
                img->gamma_data.k_val = 0;
                img->gamma_data.r_val = r_val;
                img->gamma_data.k_flip = 0;
                img->gamma_data.r_flip = r_flip;
                img->gamma_data.pregamma_offset = pregamma_offset;
            }
            else
            {
                img->gamma_data.gamma_value = bsr.read(8) / 10.0;
                img->gamma_data.offset_16 =
                    bsr.read(16) << (img->gamma_data.out_bitdepth -
                                          img->gamma_data.in_bitdepth);
                if (gamma_type == raw_gamma_type_none)
                {
                    img->gamma_data.gamma_value = 1.0;
                    img->gamma_data.offset_16 = 0;
                }
                bsr.read(43);
            }
            img->gamma_data.hardcoded_bayer_tweaks = bsr.read(1) == 0;
            bsr.read(4);
            img->gamma_data.gamma_type = gamma_type;
            img->gamma_data.enabled =
                img->gamma_data.gamma_type != raw_gamma_type_none;
        }
        if (caps->nikonhe_cap_qux_dwt53_bayer)
            qux_dwt53_bayer = bsr.read(1);
        if (caps->nikonhe_cap_qux_ycbcr_bayer)
            qux_ycbcr_bayer = bsr.read(1);
        if (caps->nikonhe_cap_diff_vh_lvls_per_comp)
            diff_vh_lvls_per_comp = bsr.read(1);
        bsr.align(8);
        if (img->v_lines > 2
            || qux_dwt53_bayer != 1
            || qux_ycbcr_bayer != 1
            || diff_vh_lvls_per_comp != 1)
            // we only support bayer profiles
            return NIKONHE_GENERIC_ERROR;
        extra_sgmt_sz = (bsr.used_bits(&data[index]) + 7) / 8;
        index += extra_sgmt_sz;
    }
    else
    {
        extra_sgmt_sz = 0;
    }
    if (lpih != extra_sgmt_sz + 26)
        return NIKONHE_GENERIC_ERROR;

    if (img->gamma_data.hardcoded_bayer_tweaks)
    {
        img->input_scale -= 2;
    }
    if (img->gamma_data.enabled
        && img->gamma_data.out_bitdepth != img->input_scale)
    {
        return NIKONHE_GENERIC_ERROR;
    }
    if (img->gamma_data.enabled == 0
        && qux_dwt53_bayer == 0
        && qux_ycbcr_bayer == 0
        && (img->is_nikonhe_long_packet_hdr == 0
            || caps->nikonhe_cap_ver_first_of_slice == 0
            || caps->nikonhe_cap_b_gains == 0
            || caps->nikonhe_cap_custom_prog_orders == 0
            || caps->nikonhe_cap_gamma_transform == 0
            || caps->nikonhe_cap_qux_dwt53_bayer == 0
            || caps->nikonhe_cap_qux_ycbcr_bayer == 0
            || caps->nikonhe_cap_diff_vh_lvls_per_comp == 0
            || img->h_lvl != 6
            || img->v_lvl != 2
            || img->ppoc != NIKONHE_PPOC_VCGH
            || img->input_scale != 16
            || img->prequant != 4
            || img->is_uniform_q != 0
            || img->signs_separate != 0
            || img->slh_pix != 64))
        return NIKONHE_GENERIC_ERROR;
    if (index + 2 > len)
        return NIKONHE_GENERIC_ERROR;

    // CDT parsing
    uint16_t cdt = be16(*(uint16_t *)&data[index]);
    index += 2;
    if (cdt != XS_MARKER_CDT)
        return NIKONHE_GENERIC_ERROR;
    if (index + 2 > len)
        return NIKONHE_GENERIC_ERROR;
    uint16_t lcdt = be16(*(uint16_t *)&data[index]);
    index += 2;
    uint16_t expected_lcdt = 2 * img->n_comp + 2;
    if (diff_vh_lvls_per_comp)
        expected_lcdt += img->n_comp;
    if (lcdt != expected_lcdt)
        return NIKONHE_GENERIC_ERROR;
    bsr.init(&data[index], len - index);
    for (int comp = 0; comp < img->n_comp; ++comp)
    {
        int depth = bsr.read(8);
        int hor_ss = bsr.read(4);
        int ver_ss = bsr.read(4);
        if (hor_ss < 1 || hor_ss > 2 || ver_ss != 1)
            return NIKONHE_GENERIC_ERROR;
        if (diff_vh_lvls_per_comp)
        {
            int hor_ndecomp = bsr.read(4);
            int ver_ndecomp = bsr.read(4);
            img->skip_decomp[comp] = hor_ndecomp == 0 && ver_ndecomp == 0;
            if (comp != 2 && (hor_ndecomp != img->h_lvl - 1 || ver_ndecomp != img->v_lvl - 1))
                return NIKONHE_GENERIC_ERROR;
            if (comp == 2 && (hor_ndecomp || ver_ndecomp))
                return NIKONHE_GENERIC_ERROR;
        }
        if (comp)
        {
            if (depth != img->depth)
                return NIKONHE_GENERIC_ERROR;
        }
        else
        {
            img->depth = depth;
        }
        if (comp == 1 && hor_ss == 2)
        {
            img->is_422 = 1;
        }
        else if (comp == 2 && img->is_422 && hor_ss != 2)
        {
            return NIKONHE_GENERIC_ERROR;
        }
        index += diff_vh_lvls_per_comp + 2;
    }
    img->h_pad_pix = 0;
    if (img->h_pix % 4)
    {
        img->h_pad_pix = 4 - img->h_pix % 4;
        img->h_pix += img->h_pad_pix;
    }
    img->w_pix /= 2;
    img->h_pix /= 2;
    if (img->n_comp > 4
        || img->n_comp < 1
        || img->h_lvl > 6
        || img->v_lvl > 3
        || img->v_lvl < 2
        || img->slh_pix < 1
        || img->slh_pix > 64
        || img->depth > 16
        || img->depth < 1
        || img->input_scale > 32
        || img->input_scale < img->depth
        || img->prequant > 24
        || img->slh_pix % img->v_lines
        || img->h_pix <= img->v_lines)
    {
        return NIKONHE_GENERIC_ERROR;
    }
    if (img->w_pix < (img->h_lvl >= 1 ? 1 << (img->h_lvl - 1) : 1))
        return NIKONHE_GENERIC_ERROR;

    err_code_t rv = nikonhe_init_image_data(img);
    if (rv)
        return rv;
    if (index + 2 > len)
        return NIKONHE_GENERIC_ERROR;

    // Weights parsing
    uint16_t wgt = be16(*(uint16_t *)&data[index]);
    index += 2;
    if (wgt != XS_MARKER_WGT)
        return NIKONHE_GENERIC_ERROR;
    if (index + 2 > len)
        return NIKONHE_GENERIC_ERROR;
    uint16_t lwgt = be16(*(uint16_t *)&data[index]);
    index += 2;
    if (lwgt != 2 * img->num_sb + 2)
        return NIKONHE_GENERIC_ERROR;
    memset(img->sb_gains, 0, sizeof(img->sb_gains));
    memset(img->sb_priorities, 72, sizeof(img->sb_priorities));
    if (2 * img->num_sb + index > len)
        return NIKONHE_GENERIC_ERROR;

    for (int sb_idx = 0; sb_idx < img->num_sb; ++sb_idx)
    {
        uint32_t current_sba = img->sp_sb_order[sb_idx];
        img->sb_gains[current_sba] = data[index++];
        img->sb_priorities[current_sba] = data[index++];
        if (img->sb_priorities[current_sba] > 0x48u)
            return NIKONHE_GENERIC_ERROR;
    }
    memset(img->sb_by_priorities, -1, sizeof(img->sb_by_priorities));
    for (int sb_idxa = 0; sb_idxa < img->num_sb; ++sb_idxa)
    {
        uint32_t current_sb = img->sp_sb_order[sb_idxa];
        if (img->sb_by_priorities[img->sb_priorities[current_sb]] != -1)
            return NIKONHE_GENERIC_ERROR;
        img->sb_by_priorities[img->sb_priorities[current_sb]] = current_sb;
    }
    if (index + 2 > len)
        return NIKONHE_GENERIC_ERROR;
    while (be16(*(uint16_t *)&data[index]) == XS_MARKER_COM)
    {
        index += 2;
        if (index + 2 > len)
            return NIKONHE_GENERIC_ERROR;
        uint16_t lext = be16(*(uint16_t *)&data[index]);
        index += lext;
    }
    return (int)index;
}

static libraw_inline int gamma_mapped_nc(
        int value,
        int scale_offset,
		int scale,
        uint32_t max_value,
        const gamma_lut_t *gamma_lut)
{
	int dec_value = gamma_lut->lut[clamp(value, 0, gamma_lut->size - 1)];
    return clamp((scale_offset + dec_value) >> scale, 0, max_value);
}

int32_t get_gamma_lut_size(const gamma_data_t *gamma_data)
{
    raw_gamma_type_t gamma_type = gamma_data->gamma_type;
    if (gamma_type == raw_gamma_type_curve_inversion)
    {
        return gamma_data->offset_sqrt + 0x10001;
    }
    else if (gamma_data->gamma_type <= raw_gamma_type_shifted)
    {
        return 4 * gamma_data->offset_16 + 0x10001;
    }
    else
    {
        return NIKONHE_GENERIC_ERROR;
    }
}

int32_t degamma_fliproot_to_squashroot_ref(const gamma_data_t *gamma, int32_t n_in)
{
    if (n_in <= gamma->offset_sqrt)
        return gamma->offset_16
               - ((uint64_t)((gamma->offset_sqrt - n_in) * (int64_t)(gamma->offset_sqrt - n_in)
                             + 0x8000) >> 16);
    if (n_in >= 0x10000)
        n_in = 0xFFFF;
    uint64_t res = (uint64_t)(gamma->r_flip * (int64_t)(n_in - gamma->offset_sqrt) + 0x8000) >> 16;
    if (((res * res + 0x8000) >> 16) + gamma->offset_16 < 0x10000)
        return ((res * res + 0x8000) >> 16) + gamma->offset_16;
    else
        return 0xFFFF;
}

int32_t degamma_linear_to_squashroot_ref(const gamma_data_t *gamma, int32_t n_in)
{
    if (n_in <= 4 * gamma->offset_16)
        return n_in >> 2;
    if (n_in >= 0x10000)
        n_in = 0xFFFF;
    uint64_t out_kr = (uint64_t)(gamma->r_val * (int64_t)(n_in - 4 * gamma->offset_16) + 0x8000) >> 16;
    if (((out_kr * out_kr) >> 16) + gamma->offset_16 < 0x10000)
        return ((out_kr * out_kr) >> 16) + gamma->offset_16;
    else
        return 0xFFFF;
}

int32_t degamma_linear_to_squashroot(const gamma_data_t *gamma, int32_t n_in)
{
    if (n_in > 0)
        return gamma->pregamma_offset + degamma_linear_to_squashroot_ref(gamma, n_in);
    else
        return gamma->pregamma_offset;
}

err_code_t calc_gamma_lut(gamma_lut_t *gamma_lut, const gamma_data_t *gamma_data)
{
    typedef int (*gamma_calc_f)(const gamma_data_t *, int);

    if (gamma_data->gamma_type > raw_gamma_type_shifted)
        return NIKONHE_GENERIC_ERROR;

    gamma_calc_f gamma_func =
        gamma_data->gamma_type == raw_gamma_type_curve_inversion
            ? degamma_fliproot_to_squashroot_ref
            : degamma_linear_to_squashroot;

    gamma_lut->size = get_gamma_lut_size(gamma_data);
    for (int i = 0; i < gamma_lut->size; ++i)
        gamma_lut->lut[i] = gamma_func(gamma_data, i);

    return NIKONHE_SUCCESS;
}

void idwt53_lift(int32_t *out, const int32_t *in_even, const int32_t *in_odd, int len)
{
    int32_t d1n = in_odd[0];
    int32_t s0n = in_even[0] - ((in_odd[0] + 1) >> 1);
    int i = 0;
    for (; i < len - 3; i += 2)
    {
        int32_t d1c = d1n;
        int32_t s0c = s0n;
        d1n = in_odd[i / 2 + 1];
        s0n = in_even[i / 2 + 1] - ((d1n + d1c + 2) >> 2);
        out[i] = s0c;
        out[i + 1] = ((s0n + s0c) >> 1) + d1c;
    }
    out[i] = s0n;
    if ((len & 1) != 0)
    {
        out[len - 1] = in_even[(len - 1) / 2] - ((d1n + 1) >> 1);
        out[len - 2] = ((out[len - 1] + s0n) >> 1) + d1n;
    }
    else
        out[len - 1] = s0n + d1n;
}

void idwt53_lift_all(int32_t *out, int32_t *tmp, int32_t *in, int len, int lvl, int *odd_ofs)
{
    int32_t* bi = in;
    while (lvl > 0)
    {
        int32_t* odd = &in[odd_ofs[lvl]];
        int lvl_len = ((1 << (lvl - 1)) + len - 1) >> (lvl - 1);
        if (lvl == 1)
            idwt53_lift(out, bi, odd, lvl_len);
        else
            idwt53_lift(tmp, bi, odd, lvl_len);
        int32_t* bs = bi;
        bi = tmp;
        tmp = bs;
        --lvl;
    }
}

void idwt53_ver_lift_tile(
        const int32_t *in_ptr,
        int32_t *out_ptr,
        int32_t *b1_ptr,
        int32_t *b2_ptr,
        int w,
        idwt_state_t *state,
        const int upscale)
{
    switch (*state)
    {
        case IDWT_STATE_HFM1_FOT:
            if (upscale)
                *state = IDWT_STATE_LF0_UP;
            else
            {
                for (int col = 0; col < w; ++col)
                    b1_ptr[col] = in_ptr[col];
                *state = IDWT_STATE_LF0_FOT;
            }
            break;
        case IDWT_STATE_LF0_FOT:
            for (int col = 0; col < w; ++col)
                b1_ptr[col] = (in_ptr[col] << 2) - b1_ptr[col];
            *state = IDWT_STATE_HF0;
            break;
        case IDWT_STATE_LF0_FOI:
            for (int col = 0; col < w; ++col)
                b1_ptr[col] = in_ptr[col] << 2;
            *state = IDWT_STATE_HF0_FOI;
            break;
        case IDWT_STATE_LF0_UP:
            for (int col = 0; col < w; ++col)
                b1_ptr[col] = in_ptr[col] << 2;
            *state = IDWT_STATE_HF0;
            break;
        case IDWT_STATE_HF0:
            if (upscale)
            {
                for (int col = 0; col < w; ++col)
                    b2_ptr[col] = (b1_ptr[col] + 1) >> 2;
                *state = IDWT_STATE_LF_UP;
            }
            else
            {
                for (int col = 0; col < w; ++col)
                {
                    b2_ptr[col] = (b1_ptr[col] - in_ptr[col] + 1) >> 2;
                    b1_ptr[col] = in_ptr[col];
                }
                *state = IDWT_STATE_LF;
            }
            break;
        case IDWT_STATE_HF0_FOI:
            if (upscale)
            {
                for (int col = 0; col < w; ++col)
                    b2_ptr[col] = (b1_ptr[col] + 1) >> 2;
                *state = IDWT_STATE_LF_UP;
            }
            else
            {
                for (int col = 0; col < w; ++col)
                {
                    b2_ptr[col] = (b1_ptr[col] - 2*in_ptr[col] + 1) >> 2;
                    b1_ptr[col] = in_ptr[col];
               }
                *state = IDWT_STATE_LF;
            }
            break;
        case IDWT_STATE_LF_UP:
            if (in_ptr)
            {
                for (int col = 0; col < w; ++col)
                {
                    out_ptr[col] = b2_ptr[col];
                    b1_ptr[col] = in_ptr[col] << 2;
                }
                *state = IDWT_STATE_HF;
            }
            else
            {
                for (int col = 0; col < w; ++col)
                    out_ptr[col] = b2_ptr[col];
                *state = IDWT_STATE_GHOST_UP;
            }
            break;
        case IDWT_STATE_LF:
            if (in_ptr)
            {
                for (int col = 0; col < w; ++col)
                {
                    out_ptr[col] = b2_ptr[col];
                    b2_ptr[col]  = b2_ptr[col] + (b1_ptr[col] << 1);
                    b1_ptr[col]  = (in_ptr[col] << 2) - b1_ptr[col];
                }
                *state = IDWT_STATE_HF;
            }
            else
            {
                for (int col = 0; col < w; ++col)
                    out_ptr[col] = b2_ptr[col];
                *state = IDWT_STATE_GHOST;
            }
            break;
        case IDWT_STATE_HF:
            if (upscale)
            {
                for (int col = 0; col < w; ++col)
                {
                    int32_t b2 = b2_ptr[col];
                    b2_ptr[col]  = (b1_ptr[col] + 1) >> 2;
                    out_ptr[col] = (b2 + b2_ptr[col]) >> 1;
                }
                *state = IDWT_STATE_LF_UP;
            }
            else
            {
                for (int col = 0; col < w; ++col)
                {
                    int32_t b1 = b1_ptr[col];
                    int32_t b2 = b2_ptr[col];
                    int32_t b2n = (b1 - in_ptr[col] + 1) >> 2;
                    out_ptr[col] = (b2 + b2n) >> 1;
                    b1_ptr[col] = in_ptr[col];
                    b2_ptr[col] = b2n;
                }
                *state = IDWT_STATE_LF;
            }
            break;
        case IDWT_STATE_GHOST:
            for (int col = 0; col < w; ++col)
                out_ptr[col] = b1_ptr[col] + b2_ptr[col];
            *state = IDWT_FINAL;
            break;
        case IDWT_STATE_GHOST_UP:
            for (int col = 0; col < w; ++col)
                out_ptr[col] = b2_ptr[col];
            *state = IDWT_FINAL;
            break;
        default:
            // error - unknown state
            break;
    }
}

ptrdiff_t nikonhe_stage_data_idwt_h1_l12(
        nikonhe_decoder* dec,
        int line,
        int h_lvl_drop,
        int h_lvl_skip,
        unsigned int width_factor,
        unsigned int width_factor_exp,
        bool full_idwt_hor,
        int32_t* in_ptr,
        int32_t* tmp_ptr,
        int32_t* out_ptr,
        int32_t* no_idwt_out_ptr)
{
    nikonhe_image* img = &dec->img;
    ptrdiff_t ofs_out = 0;
    for (int comp = 0; comp < img->n_comp; ++comp)
    {
        if (!img->skip_decomp[comp])
        {
            idwt53_lift_all(
                &out_ptr[ofs_out],
                tmp_ptr,
                &in_ptr[4 * img->seg_grp[img->pos_seg[comp][line][0]].ofs_grp],  // h_lvl=0
                (width_factor + img_width(img, comp) - 1) / width_factor,
                h_lvl_drop - 1,
                &img->odd_ofs[comp][line][width_factor_exp]);
            ofs_out += full_idwt_hor ? 2 * img->semi_comp_chunks[comp]
                                     : img->semi_comp_chunks[comp];
        }
    }
    for (int comp = 0; comp < img->n_comp; ++comp)
    {
        if (img->skip_decomp[comp])
        {
            // skipped component always 2
            assert(comp == 2);
            // has to be full_idwt_hor
            assert(full_idwt_hor);
            memcpy(&no_idwt_out_ptr[ofs_out],
                   &in_ptr[4 * img->seg_grp[img->pos_seg[2][line][0]].ofs_grp],  // h_lvl=0
                   4 * ((width_factor + img_width(img, 2) - 1) / width_factor));
            ofs_out += 2 * img->semi_comp_chunks[2];
        }
    }
    return ofs_out;
}

bool nikonhe_stage_data_idwt_v2(
        nikonhe_decoder *dec,
        stage1_data* stage_data,
        const int prec_idx,
        const int v_line,
        int32_t *in_ptr,
        int32_t *out_ptr)
{
    nikonhe_image* img = &dec->img;
    int32_t* b1 = stage_data->idwt_b1_v2;
    int32_t* b2 = stage_data->idwt_b2_v2;
    bool reachedEndState = stage_data->idwt_state[0] >= IDWT_STATE_LF_UP;
    for (int c = 0; c < img->n_comp; ++c)
    {
        int w = img->skip_decomp[c] ? 0 : 2 * img->semi_comp_chunks[c];
        idwt53_ver_lift_tile(
            in_ptr,
            out_ptr,
            b1,
            b2,
            w,
            &stage_data->idwt_state[c],
            v_line >= 0 && in_ptr
                && stage_data->seg_empty[img->pos_seg[c][v_line][0]]      // h_lvl = 0
                && stage_data->seg_empty[img->pos_seg[c][v_line][1]]);    // h_lvl = 1
        if (in_ptr)
            in_ptr += w;
        if (out_ptr)
            out_ptr += w;
        b1 += w;
        b2 += w;
    }
    return reachedEndState;
}

int get_sb_gtli(const nikonhe_image *img, int scenario, int refinement, gtli_pairs_t *gtli_sb)
{
    for (int sb = 0; sb < 72; ++sb)
    {
        if (img->sb_seg[sb][0] >= 0)
        {
            int v = scenario - img->sb_gains[sb];
            if (v > 0)
            {
                gtli_sb->truncation[sb] = std::min(v-1, 15);
                gtli_sb->data[sb]  = std::min(v-(img->sb_priorities[sb] < refinement), 15);
            }
            else
            {
                gtli_sb->truncation[sb] = 0;
                gtli_sb->data[sb] = 0;
            }
        }
    }
    return 0;
}

err_code_t nikonhe_decode_gtli_gcli_coeffs(
        const nikonhe_image *img,
        bitstream_reader *bsr_sig,   // significance
        bitstream_reader *bsr_gcli,  // gcli - bitplane counts
        bitstream_reader *bsr_data,  // quantized coefs
        bitstream_reader *bsr_sign,  // signs data if any
        const uint32_t sp_idx,  // packet idx
        const uint8_t pkt_is_raw,
        const uint8_t *sb_gcli_coding,
        const gtli_pairs_t *gtli_sb,
        const gtli_pairs_t *gtli_sb_prev,
        uint8_t *gcli_buff,
        uint8_t *h_gcli0,
        int32_t *coeffs_buff,
        const int first_of_slice,
        bool *seg_empty,
        const int max_seg)
{
    for (int seg_idx = 0; seg_idx < img->sp_seg_size[sp_idx]; ++seg_idx)
    {
        int current_seg = img->sp_seg[sp_idx][seg_idx];
        int pv_seg = img->seg_pv[current_seg];
        int current_sb = img->seg_sb[current_seg];
        int ofs_grp = img->seg_grp[current_seg].ofs_grp;
        int ofs_grp_pv = img->seg_grp[img->seg_pv[current_seg]].ofs_grp;
        int len_grp = img->seg_grp[current_seg].len_grp;    // component wavelet width for the level essentially
        //int sig_len_bits = 0; // significance coding if used;
        uint8_t gcli_coding = pkt_is_raw ? 0 : sb_gcli_coding[img->seg_sb[current_seg]];
        uint8_t* gcli = &gcli_buff[ofs_grp];
        uint8_t* gcli_prev = &gcli_buff[ofs_grp_pv];
        if (first_of_slice && (gcli_coding & 3) == 3 && ofs_grp_pv - ofs_grp >= 0)
            gcli_coding = (gcli_coding & ~3) | 1;
        seg_empty[current_seg] = false;
        if (gcli_coding)
        {
            switch (gcli_coding)
            {
                case 2:
                    gcli[0] = h_gcli0[current_seg];
                    for (int i = 1; i < len_grp; ++i)
                        gcli[i] = gcli[i-1] + bsr_gcli->read_unary_signed();
                    break;
                case 3:
                    for (int i = 0; i < len_grp; ++i)
                        gcli[i] = bsr_gcli->read_unary_signed() + gcli_prev[i];
                    break;
                case 0x12:
                    gcli[0] = h_gcli0[current_seg] + gtli_sb->truncation[current_sb];
                    for (int i = 1; i < len_grp; ++i)
                        gcli[i] = gcli[i-1] + bsr_gcli->read_unary_signed();
                    break;
                case 0x13:
                    for (int i = 0; i < len_grp; ++i)
                        gcli[i] = bsr_gcli->read_unary_signed() + std::max(gcli_prev[i], gtli_sb->truncation[current_sb]);
                    break;
                case 0x51:
                    // prediction from 0, no significance
                    seg_empty[current_seg] = true;
                    for (int i = 0; i < len_grp; ++i)
                    {
                        gcli[i] = gtli_sb->data[current_sb] + bsr_gcli->read_unary_unsigned_bounded();
                        seg_empty[current_seg] = seg_empty[current_seg] && gcli[i]==0;
                    }
                    break;
                case 0x53:
                    // vertical prediction, no significance
                    for (int i = 0; i < len_grp; ++i)
                        gcli[i] = predict_lut_gtli[bsr_gcli->read_unary_unsigned_bounded()
                                                   | (gcli_prev[i] << 5)
                                                   | (gtli_sb->data[current_sb] << 9)];
                    break;
                case 0x71:
                    // prediction from 0, significance coding enabled
                    // significance length = group length/n_code_group_per_sig_group (always 8)
                    seg_empty[current_seg] = true;
                    for (int sig_grp=0, code_grp=0; sig_grp < (len_grp + 7) >> 3;  ++sig_grp)
                    {
                        bool all_insignificant = bsr_sig->read(1);
                        seg_empty[current_seg] = seg_empty[current_seg] && all_insignificant;
                        for (int i = 0; i < 8 && code_grp < len_grp; ++i, ++code_grp)
                        {
                            gcli[code_grp] = gtli_sb->data[current_sb];
                            if (!all_insignificant)
                                gcli[code_grp] += bsr_gcli->read_unary_unsigned_bounded();
                        }
                    }
                    break;
                case 0x73:
                    // vertical prediction, significance coding enabled
                    // only for runs indicating zero coeff we can have empty segment
                    seg_empty[current_seg] = img->is_run_mode_zero_coeff;
                    for (int sig_grp=0, code_grp=0; sig_grp < (len_grp + 7) >> 3;  ++sig_grp)
                    {
                        bool all_insignificant = bsr_sig->read(1);
                        seg_empty[current_seg] = seg_empty[current_seg] && all_insignificant;
                        uint8_t gtli_data = current_seg > pv_seg ? gtli_sb->data[current_sb]
                                                                 : gtli_sb_prev->data[current_sb];

                        for (int i = 0; i < 8 && code_grp < len_grp; ++i, ++code_grp)
                        {
                            if (all_insignificant)
                            {
                                gcli[code_grp] = (img->is_run_mode_zero_coeff
                                                  || (seg_empty[pv_seg] && gtli_data <= gtli_sb->data[current_sb]))
                                                    ? gtli_sb->data[current_sb]
                                                    : predict_lut_gtli[(gcli_prev[code_grp] << 5) |
                                                                       (gtli_sb->data[current_sb] << 9)];
                            }
                            else
                            {
                                gcli[code_grp] = seg_empty[pv_seg] && gtli_data <= gtli_sb->data[current_sb]
                                                    ? gtli_sb->data[current_sb] + bsr_gcli->read_unary_unsigned_bounded()
                                                    : predict_lut_gtli[bsr_gcli->read_unary_unsigned_bounded()
                                                                               | (gcli_prev[code_grp] << 5)
                                                                               | (gtli_sb->data[current_sb] << 9)];
                            }
                        }
                    }
                    break;
                default:
                    return NIKONHE_GENERIC_ERROR;
            }
        }
        else
        {
            for (int i = 0; i < len_grp; ++i)
                gcli[i] = std::max((uint8_t)bsr_gcli->read(BITS_IN_BITPLANE),
                                    gtli_sb->data[current_sb]);
        }
        if (bsr_data && coeffs_buff)
        {
            if (seg_empty[current_seg])
            {
                // for (int grp = ofs_grp; grp < ofs_grp + len_grp; ++grp)
                // {
                //     memset(&coeffs_buff[4 * grp], 0, 4*sizeof(int32_t)); //???
                // }
                if (max_seg == 0 || current_seg <= max_seg)
                    memset(&coeffs_buff[N_COEFF_IN_GROUP*ofs_grp], 0, N_COEFF_IN_GROUP*sizeof(int32_t)*len_grp);
            }
            else
            {
                seg_empty[current_seg] = true;
                uint8_t gtli = gtli_sb->data[img->seg_sb[current_seg]];
                int scale = img->prequant;
                for (int grp = ofs_grp; grp < ofs_grp + len_grp; ++grp)
                {
                    int n_bits = gcli_buff[grp] - gtli;
                    int32_t* coeffs = &coeffs_buff[N_COEFF_IN_GROUP * grp];
                    memset(coeffs, 0, N_COEFF_IN_GROUP*sizeof(uint32_t));
                    if (n_bits > 0)
                    {
                        seg_empty[current_seg] = false;
                        if (img->signs_separate)
                        {
                            if (img->is_uniform_q)
                                bsr_data->get_coeffs_uniform_dq_nosigns((uint32_t*)coeffs, n_bits, gtli, scale);
                            else
                                bsr_data->get_coeffs_deadzone_dq_nosigns((uint32_t*)coeffs, n_bits, gtli, scale);
                            // apply signs
                            for (int i=0; i<N_COEFF_IN_GROUP; ++i)
                                if (coeffs[i] && bsr_sign->read(1))
                                    coeffs[i] = -coeffs[i];
                        }
                        else if (img->is_uniform_q)
                            bsr_data->get_coeffs_uniform_dq(coeffs, n_bits, gtli, scale);
                        else
                            bsr_data->get_coeffs_deadzone_dq(coeffs, n_bits, gtli, scale);
                    }
                }
            }
        }
    }
    if (bsr_data)
        bsr_data->align(8);
    bsr_sig->align(8);
    bsr_gcli->align(8);
    bsr_sign->align(8);
    return NIKONHE_SUCCESS;
}

err_code_t decode_coeff(
        const nikonhe_image* img,
        stage1_data* stage_data,
        const int prec_idx,
        const int packet_idx,
        int32_t *coeffs_buff,
        const uint8_t* first_invalid_data,
        const uint8_t* buf_end,
        const int first_of_slice,
        const int max_seg)
{
    precinct_data_t* precinct = &stage_data->precincts[prec_idx];
    packet_data_t* packet = &precinct->packets[packet_idx];

    bitstream_reader bsr_data;
    bitstream_reader bsr_sig(packet->sig_start, buf_end);
    bitstream_reader bsr_sign(packet->sign_start, buf_end);
    bitstream_reader bsr_gcli(bsr_sig);
    bitstream_reader from_br(bsr_sig);
    if (packet->sig_len)
        bsr_gcli.discard_long(packet->sig_len*8);

    if (coeffs_buff)
        bsr_data.init(packet->data_start, first_invalid_data);

    err_code_t ret =
        nikonhe_decode_gtli_gcli_coeffs(
            img,
            &bsr_sig,
            &bsr_gcli,
            coeffs_buff ? &bsr_data : 0,
            &bsr_sign,
            packet_idx,
            packet->pkt_is_raw,
            precinct->sb_gcli_coding,
            &precinct->gtlis_sb,
            prec_idx ? &stage_data->precincts[prec_idx - 1].gtlis_sb : 0,
            stage_data->gcli,
            stage_data->h_gcli0,
            coeffs_buff,
            first_of_slice,
            stage_data->seg_empty,
            max_seg);

    if (ret == NIKONHE_SUCCESS)
    {
        if (coeffs_buff && bsr_data.used_bits(packet->data_start) != packet->data_len*8)
            ret = NIKONHE_GENERIC_ERROR;
        else if (bsr_sign.used_bits(packet->sign_start) != packet->sign_len*8)
            ret = NIKONHE_GENERIC_ERROR;
        else if (bsr_sig.bits_diff_from(&from_br) != packet->sig_len*8)
            ret = NIKONHE_GENERIC_ERROR;
        else if (bsr_gcli.bits_diff_from(&from_br) - packet->sig_len*8 != packet->gcli_len*8)
            ret = NIKONHE_GENERIC_ERROR;
    }
    return ret;
}

err_code_t jpegxs_stage1_tile_decode(
        nikonhe_decoder* dec,
        int tile_start,
        int tile_height,
        const uint8_t* tile_data,
        uint32_t tile_data_len,
        stage1_data* stage_data)
{
    int h_lvl_drop[2];
    int h_lvl_skip[2];

    err_code_t ret = NIKONHE_SUCCESS;

    const nikonhe_image* img = &dec->img;
    uint8_t* first_invalid_data = (uint8_t*)dec->data_buf
                                          + dec->data_len;

    h_lvl_skip[0] = std::min((int)img->h_lvl, img->h_lvl - img->v_lvl + 2);
    h_lvl_skip[1] = h_lvl_skip[0] - (img->h_lvl - img->v_lvl);
    h_lvl_drop[0] = std::min((int)img->h_lvl, img->h_lvl - img->v_lvl + 2);
    h_lvl_drop[1] = h_lvl_drop[0] - (img->h_lvl - img->v_lvl);

    unsigned int width_factor_exp = img->h_lvl - h_lvl_skip[0];
    int width_factor = 1 << width_factor_exp;

    // Parse slices, precincts and packets headers
    bitstream_reader bsr(tile_data, tile_data_len);
    for (int i = tile_start; i < std::min(tile_start + tile_height + 2*img->v_lines, img->h_pix); i += img->v_lines)
    {
        if (i > tile_start && i % img->slh_pix == 0)
        {
            // read slice header
            int expected_slice_idx = i / img->slh_pix;
            unsigned int header_word = bsr.read(16);
            unsigned int size_word = bsr.read(16);
            unsigned int index_word = bsr.read(16);
            // header_word == XS_MARKER_SLH && size_word == 4 && index_word == expected_slice_idx
            assert(header_word == XS_MARKER_SLH
                   && size_word == 4
                   && index_word == expected_slice_idx);
        }
        // we are at precinct header now
        precinct_data_t* precinct = &stage_data->precincts[(i - tile_start) / img->v_lines];
        precinct->prec_idx = i / img->v_lines;
        uint8_t* prec_data_start_ptr = bsr.current_ptr();
        precinct->prec_len = precinct_header_size(img) + bsr.read(24);
        precinct->quantisation = bsr.read(8);   // precinct quantization Qp
        precinct->refinement = bsr.read(8);    // precinct refinement Rp
        get_sb_gtli(img, precinct->quantisation, precinct->refinement, &precinct->gtlis_sb);
        // loop over bands to parse bitplane coding data
        for (int j = 0; j < img->num_sb; ++j)
        {
            precinct->sb_gcli_coding[img->sp_sb_order[j]] = 0x40;
            if (bsr.read(1))
                // significance coding enabled - significance groups will be present
                precinct->sb_gcli_coding[img->sp_sb_order[j]] |= 0x20;
            if (bsr.read(1))
                // vertical prediction
                precinct->sb_gcli_coding[img->sp_sb_order[j]] |= 0x13;
            else
                // prediction from 0
                precinct->sb_gcli_coding[img->sp_sb_order[j]] |= 0x11;
        }

        for (int j = 0; j < img->nb_pkt; ++j)
            precinct->packets[j].sig_len = 0;
        for (int j = 0; j < img->nb_seg; ++j)
            if (precinct->sb_gcli_coding[img->seg_sb[j]] & 0x20)
                // significance coding enabled - significance lenth is in bits
                // and equals to group length/n_code_group_per_sig_group (the latter is always 8)
                precinct->packets[img->seg_pkt[j]].sig_len += (img->seg_grp[j].len_grp + 7) >> 3;

        // precinct headers are padded to byte boundary
        bsr.align(8);

        // loop over packets in a precinct
        for (int j = 0; j < img->nb_pkt; ++j)
        {
            // packet header parsing
            precinct->packets[j].pkt_is_raw = bsr.read(1);
            if (img->n_comp * img->w_pix < 0x8000
                && img->v_lvl - 1 <= 3
                && !img->is_nikonhe_long_packet_hdr
                && img->ppoc == NIKONHE_PPOC_RPBC)
            {
                precinct->packets[j].data_len = bsr.read(15); // size of data subpacket in bytes
                precinct->packets[j].gcli_len = bsr.read(13); // size of the bitplane count subpacket in bytes
                precinct->packets[j].sign_len = bsr.read(11); // size of the sign subpacket in bytes
            }
            else
            {
                precinct->packets[j].data_len = bsr.read(20); // size of data subpacket in bytes
                precinct->packets[j].gcli_len = bsr.read(20); // size of the bitplane count subpacket in bytes
                precinct->packets[j].sign_len = bsr.read(15); // size of the sign subpacket in bytes
            }

            // packet headers are padded to byte boundary
            bsr.align(8);

            if (precinct->packets[j].pkt_is_raw)
                precinct->packets[j].sig_len = 0;
            precinct->packets[j].sig_len = ((precinct->packets[j].sig_len + 7) >> 3) & 0x1FFFFFFF;

            // data for the packet
            precinct->packets[j].sig_start = bsr.current_ptr();
            precinct->packets[j].gcli_start = &precinct->packets[j].sig_start[precinct->packets[j].sig_len];
            precinct->packets[j].data_start = &precinct->packets[j].gcli_start[precinct->packets[j].gcli_len];
            precinct->packets[j].sign_start = &precinct->packets[j].data_start[precinct->packets[j].data_len];

            // skip all the data for now to parse next packet
            bsr.discard_long(8 * (precinct->packets[j].sign_len
                             + precinct->packets[j].data_len
                             + precinct->packets[j].gcli_len
                             + precinct->packets[j].sig_len));
        }

        // advance through padding
        precinct->padding_len = precinct->prec_len - (bsr.current_ptr() - prec_data_start_ptr);
        if (precinct->padding_len >= 0)
            bsr.discard_long(8 * precinct->padding_len);
        else
        {
            ret = NIKONHE_GENERIC_ERROR;
            break;
        }
    }

    // headers data parsed
    if (ret == NIKONHE_SUCCESS)
    {
        int32_t* no_idwt_out_ptr = &dec->in_bayer_stage1[img->line_stride * tile_start];
        int32_t* worker_buffs = stage_data->worker_buffs;
        int32_t* out_ptr = &worker_buffs[img->line_stride];
        int32_t* tmp_ptr = &worker_buffs[2 * img->line_stride];
        int prec_idx = 0;
        for (int i = 0; i < img->n_comp; ++i)
            stage_data->idwt_state[i] = !tile_start ? IDWT_STATE_LF0_FOI : IDWT_STATE_HFM1_FOT;
        int line_offset = tile_start ? tile_start + 2 : 0;
        for (int i = tile_start; i < tile_start + tile_height + 4 && i < img->h_pix; i += 2)
        {
            bool condA = i + 2 >= img->h_pix
                         && tile_height + tile_start == img->h_pix;
            bool condB = i + 2 >= tile_height + tile_start + 4
                         || condA;
            int prec_line = (i - tile_start) / 2;
            if (i == tile_start && i != 0)
            {
                for (int line = 0; line < 2; ++line)
                {
                    int32_t* coeff_buf = &worker_buffs[-(img->line_stride * line)];
                    if (img->ppoc == NIKONHE_PPOC_RPBC)
                    {
                        ret = decode_coeff(
                                img,
                                stage_data,
                                prec_line,
                                line ? 2 : 0,
                                coeff_buf,
                                first_invalid_data,
                                &tile_data[tile_data_len],
                                i % img->slh_pix == 0,
                                0);
                        if (ret == NIKONHE_SUCCESS)
                        {
                            ret = decode_coeff(
                                    img,
                                    stage_data,
                                    prec_line,
                                    line ? 3 : 1,
                                    coeff_buf,
                                    first_invalid_data,
                                    &tile_data[tile_data_len],
                                    i % img->slh_pix == 0,
                                    0);
                        }
                    }
                    else if (img->ppoc == NIKONHE_PPOC_VCGH)
                    {
                        for (int comp = 0; comp < img->n_comp; ++comp)
                        {
                            ret = decode_coeff(
                                    img,
                                    stage_data,
                                    prec_line,
                                    line*img->n_comp + comp,
                                    coeff_buf,
                                    first_invalid_data,
                                    &tile_data[tile_data_len],
                                    i % img->slh_pix == 0,
                                    0);
                        }
                    }
                    else if (img->ppoc == NIKONHE_PPOC_VGCH)
                    {
                        ret = decode_coeff(
                                img,
                                stage_data,
                                prec_line,
                                line,
                                coeff_buf,
                                first_invalid_data,
                                &tile_data[tile_data_len],
                                i % img->slh_pix == 0,
                                0);
                    }
                    if (ret != NIKONHE_SUCCESS)
                        return ret;
                    no_idwt_out_ptr += nikonhe_stage_data_idwt_h1_l12(
                                           dec,
                                           line,
                                           h_lvl_drop[line],
                                           h_lvl_skip[line],
                                           width_factor,
                                           width_factor_exp,
                                           img->v_lvl == 2,
                                           coeff_buf,
                                           tmp_ptr,
                                           out_ptr,
                                           no_idwt_out_ptr);
                    if (line == 1)
                        nikonhe_stage_data_idwt_v2(dec, stage_data, prec_idx, 1, out_ptr, 0);
                }
            }
            else for (int line = 0; line < 2; ++line)
            {
                int32_t* coeff_buf = &worker_buffs[-(img->line_stride * line)];
                if (img->ppoc == NIKONHE_PPOC_RPBC)
                {
                    ret = decode_coeff(
                            img,
                            stage_data,
                            prec_line,
                            line ? 2 : 0,
                            coeff_buf,
                            first_invalid_data,
                            &tile_data[tile_data_len],
                            i % img->slh_pix == 0,
                            0);

                    if (ret == NIKONHE_SUCCESS)
                    {
                        ret = decode_coeff(
                                img,
                                stage_data,
                                prec_line,
                                line ? 3 : 1,
                                coeff_buf,
                                first_invalid_data,
                                &tile_data[tile_data_len],
                                i % img->slh_pix == 0,
                                0);
                    }
                }
                else if (img->ppoc == NIKONHE_PPOC_VCGH)
                {
                    for (int comp = 0; comp < img->n_comp; ++comp)
                    {
                        ret = decode_coeff(
                                img,
                                stage_data,
                                prec_line,
                                img->n_comp*line + comp,
                                coeff_buf,
                                first_invalid_data,
                                &tile_data[tile_data_len],
                                i % img->slh_pix == 0,
                                0);
                    }
                }
                else if (img->ppoc == NIKONHE_PPOC_VGCH)
                {
                    ret = decode_coeff(
                            img,
                            stage_data,
                            prec_line,
                            line,
                            coeff_buf,
                            first_invalid_data,
                            &tile_data[tile_data_len],
                            i % img->slh_pix == 0,
                            0);
                }

                if (ret != NIKONHE_SUCCESS)
                    return ret;
                no_idwt_out_ptr += nikonhe_stage_data_idwt_h1_l12(
                                       dec,
                                       line,
                                       h_lvl_drop[line],
                                       h_lvl_skip[line],
                                       width_factor,
                                       width_factor_exp,
                                       img->v_lvl == 2,
                                       coeff_buf,
                                       tmp_ptr,
                                       out_ptr,
                                       no_idwt_out_ptr);
                int32_t* in_ptr = &dec->in_bayer_stage1[img->line_stride * line_offset];
                if (nikonhe_stage_data_idwt_v2(dec, stage_data, prec_idx, line?line:-1, out_ptr, in_ptr))
                    ++line_offset;
            }
            if (condB && condA)
            {
                int32_t* in_ptr = &dec->in_bayer_stage1[img->line_stride * line_offset++];
                nikonhe_stage_data_idwt_v2(dec, stage_data, prec_idx, -1, 0, in_ptr);
                in_ptr = &dec->in_bayer_stage1[img->line_stride * line_offset++];
                nikonhe_stage_data_idwt_v2(dec, stage_data, prec_idx, -1, 0, in_ptr);
                line_offset += 2;
            }
            ++prec_idx;
        }
    }
    return ret;
}

void iqx_iqp_tile_step1(
        const int32_t *Cr_ptr,
        const int32_t *Yl_ptr,
        const int32_t *Yh_ptr,
        const int32_t *Cb_ptr,
        int32_t *G0_ptr_out,
        int32_t *G1_ptr_out,
        int w,
        int h,
        int planes_in_stride,
        int planes_out_stride,
        int is_first,
        int is_last)
{
    for (int row = 0; row < h; ++row)
    {
        const int32_t* Cr_ptr_reg = &Cr_ptr[planes_in_stride * row];
        const int32_t* CrDown_ptr_reg = is_last && row == h - 1
                            ? Cr_ptr_reg
                            : &Cr_ptr[planes_in_stride * (row + 1)];

        const int32_t* Yl_ptr_reg = &Yl_ptr[planes_in_stride * row];
        const int32_t* YlDown_ptr_reg = is_last && row == h - 1
                            ? Yl_ptr_reg
                            : &Yl_ptr[planes_in_stride * (row + 1)];

        const int32_t* Yh_ptr_reg = &Yh_ptr[planes_in_stride * row];
        const int32_t* YhDown_ptr_reg = is_last && row == h - 1
                            ? Yh_ptr_reg
                            : &Yh_ptr[planes_in_stride * (row + 1)];

        const int32_t* YhUp_ptr_reg = !is_first || row
                        ? &Yh_ptr[planes_in_stride * (row - 1)]
                        : Yh_ptr_reg;

        const int32_t* Cb_ptr_reg = &Cb_ptr[planes_in_stride * row];
        const int32_t* CbUp_ptr_reg = !is_first || row
                        ? &Cb_ptr[planes_in_stride * (row - 1)]
                        : Cb_ptr_reg;
        int32_t* G0_ptr_out_reg = &G0_ptr_out[planes_out_stride * row];
        int32_t* G1_ptr_out_reg = &G1_ptr_out[planes_out_stride * row];

        // non aligned 32 bit stuff
        int32_t Y0Left = 0;
        int32_t Y0LeftDown = 0;
        for (int col = 0; col < w; ++col)
        {
            int32_t CbLeft = col ? Cb_ptr_reg[col-1] : Cb_ptr_reg[0];
            int32_t Cb = Cb_ptr_reg[col];
            int32_t CrRight = col == w - 1 ? Cr_ptr_reg[col] : Cr_ptr_reg[col+1];
            int32_t Cr = Cr_ptr_reg[col];
            int32_t CrDown = CrDown_ptr_reg[col];

            int32_t YhRight = col == w - 1 ? Yh_ptr_reg[col] : Yh_ptr_reg[col+1];
            int32_t Yh = Yh_ptr_reg[col];
            int32_t YhUpRight = col == w - 1 ? YhUp_ptr_reg[col] : YhUp_ptr_reg[col+1];
            int32_t YhUp = YhUp_ptr_reg[col];
            int32_t YhDownRight = col == w - 1 ? YhDown_ptr_reg[col] : YhDown_ptr_reg[col+1];
            int32_t YhDown = YhDown_ptr_reg[col];

            int32_t Y0 = Yl_ptr_reg[col] - ((YhUp + YhUpRight + Yh + YhRight) >> 3);
            int32_t Y0Down = is_last && row == h - 1
                                ? Y0
                                : YlDown_ptr_reg[col] - ((Yh + YhRight + YhDown + YhDownRight) >> 3);
            if (!col)
            {
                Y0Left = Yl_ptr_reg[col] - ((YhUp + YhUpRight + Yh + YhRight) >> 3);
                Y0LeftDown = Y0Down;
            }
            G0_ptr_out_reg[col] = Y0 - ((Cb + CbUp_ptr_reg[col] + Cr + CrRight) >> 3);
            G1_ptr_out_reg[col] = ((Y0Down + Y0 + Y0LeftDown + Y0Left) >> 2)
                                  + Yh - ((CbLeft + Cb + Cr + CrDown) >> 3);
            Y0Left = Y0;
            Y0LeftDown = Y0Down;
        }
    }
}

uint16_t* output_stripe_ptr(int32_t stripe_idx, size_t data_size, nikonhe_decoder *dec)
{
    if (stripe_idx >= dec->output_height)
        return 0;
    if (data_size > sizeof(uint16_t) * 2 * dec->output_line_stride)
        return 0;
    return (uint16_t*)dec->output_buffer + 2 * dec->output_line_stride * stripe_idx;
}

err_code_t iqx_iqp_tile_step2(
        const int32_t* Cr_ptr,
        const int32_t* G0_ptr,
        const int32_t* G1_ptr,
        const int32_t* Cb_ptr,
        int line_start,
        int Chroma_stride,
        int Greens_stride,
        int w,
        int h,
        int h_orig,
        int matrix_stride,
        int is_first,
        int is_last,
        nikonhe_decoder *dec,
        int32_t scale,
        uint32_t depth)
{
	const int max_value = (1 << depth) - 1;
	const int scale_offset = scale > 0 ? 1 << (scale - 1) : 0;
	const int post_offset = 1 << (scale + depth - 1);

    for (int row = 0; row < h; ++row)   // row is a CFA raw line that includes 2 lines of bayer pattern
    {
        uint16_t* pix_bufs = 0;
        uint16_t* line0_ptr = 0;
        uint16_t* line1_ptr = 0;
        int nb_lines = std::min(h_orig - 2 * (line_start + row), 2);
        if (2 * (row + line_start) < h_orig)
        {
          pix_bufs = output_stripe_ptr(line_start + row, 2 * matrix_stride * nb_lines, dec);

          if (!pix_bufs)
            return NIKONHE_GENERIC_ERROR;

          line0_ptr = pix_bufs;
          if (2 * (row + line_start) + 1 < h_orig)
            line1_ptr = &pix_bufs[matrix_stride & ~1];
        }

        const int32_t* G0_reg_ptr = &G0_ptr[Greens_stride * row];
        const int32_t* G1_reg_ptr = &G1_ptr[Greens_stride * row];
        const int32_t* Cr_reg_ptr = &Cr_ptr[Chroma_stride * row];
        const int32_t* Cb_reg_ptr = &Cb_ptr[Chroma_stride * row];
        const int32_t* G0_down_reg_ptr = is_last && row == h - 1
                                            ? G0_reg_ptr
                                            : &G0_ptr[Greens_stride * (row + 1)];
        const int32_t* G1_up_reg_ptr = &G1_ptr[Greens_stride * (row - 1)];


		if (dec->gamma_lut.size)
		{
			// gamma-mapped
			for (int col = 0; col < w; ++col)
			{
				int32_t G0 = G0_reg_ptr[col];
				int32_t G0Left = col ? G0_reg_ptr[col - 1] : G0;
				int32_t G1Up = !is_first || row ? G1_up_reg_ptr[col] : G1_reg_ptr[col];
				int32_t G1 = G1_reg_ptr[col];
				int32_t G1Right = col == w - 1 ? G1 : G1_reg_ptr[col + 1];
				int32_t Red = ((G1 + G0 + G0Left + G1Up) >> 2) + Cr_reg_ptr[col];
				int32_t Blue = ((G1 + G0 + G1Right + G0_down_reg_ptr[col]) >> 2) + Cb_reg_ptr[col];
				if (line0_ptr)
				{
                  *line0_ptr++ = gamma_mapped_nc(Red + post_offset, scale_offset, scale, max_value, &dec->gamma_lut);
                  *line0_ptr++ = gamma_mapped_nc(G0 + post_offset, scale_offset, scale, max_value, &dec->gamma_lut);
				}
				if (line1_ptr)
				{
                  *line1_ptr++ = gamma_mapped_nc(G1 + post_offset, scale_offset, scale, max_value, &dec->gamma_lut);
                  *line1_ptr++ = gamma_mapped_nc(Blue + post_offset, scale_offset, scale, max_value, &dec->gamma_lut);
				}
			}
		}
		else
		{
			// linear
          for (int col = 0; col < w; ++col)
          {
            int32_t G0 = G0_reg_ptr[col];
            int32_t G0Left = col ? G0_reg_ptr[col - 1] : G0;
            int32_t G1Up = !is_first || row ? G1_up_reg_ptr[col] : G1_reg_ptr[col];
            int32_t G1 = G1_reg_ptr[col];
            int32_t G1Right = col == w - 1 ? G1 : G1_reg_ptr[col + 1];
            int32_t Red = ((G1 + G0 + G0Left + G1Up) >> 2) + Cr_reg_ptr[col];
            int32_t Blue = ((G1 + G0 + G1Right + G0_down_reg_ptr[col]) >> 2) + Cb_reg_ptr[col];
            if (line0_ptr)
            {
              *line0_ptr++ = clamp((scale_offset + Red + post_offset) >> scale, 0, max_value);
              *line0_ptr++ = clamp((scale_offset + G0 + post_offset) >> scale, 0, max_value);
            }
            if (line1_ptr)
            {
              *line1_ptr++ = clamp((scale_offset + G1 + post_offset) >> scale, 0, max_value);
              *line1_ptr++ = clamp((scale_offset + Blue + post_offset) >> scale, 0, max_value);
            }
          }
        }
    }
    return NIKONHE_SUCCESS;
}

err_code_t calc_tile_data_offsets(
        nikonhe_decoder *dec,
        const int num_tiles,
        const int tile_height,
        std::vector<tile_buf>& tile_in_data)
{
    nikonhe_image* img = &dec->img;
    size_t bofs = dec->data_ofs;
    for (int i = 0; i < num_tiles; ++i)
    {
        size_t len_slice = 0;
        size_t len_slice_ext = 0;
        int tile_lines = i== num_tiles - 1 ? img->h_pix % tile_height : tile_height;
        int y_max = std::min(img->h_pix, i*tile_height + tile_lines + 2*img->v_lines);
        for (int y_pix = i*tile_height; y_pix < y_max; y_pix += img->v_lines)
        {
            if (y_pix % img->slh_pix == 0)
            {
                // start of a new slice
                len_slice = len_slice_ext;
                uint16_t* fp = (uint16_t*)(dec->data_buf + len_slice_ext + bofs);
                if (!fp)
                    return NIKONHE_GENERIC_ERROR;
                uint16_t size_word = be16(fp[1]);
                uint16_t index_word = be16(fp[2]);
                if (be16(fp[0]) != XS_MARKER_SLH
                    || size_word != 4
                    || index_word != y_pix / img->slh_pix)
                    return NIKONHE_GENERIC_ERROR;
                len_slice_ext += 6;
            }
            const uint8_t* fp = dec->data_buf + len_slice_ext + bofs;

            if (!fp)
                return NIKONHE_GENERIC_ERROR;
            // add precinct length in bytes: header + body length
            len_slice_ext += precinct_header_size(img) +
                             ((fp[0] << 16) | (fp[1] << 8) | fp[2]);
        }
        tile_in_data[i].in_buf= dec->data_buf + bofs + 6;
        if (!tile_in_data[i].in_buf)
            return NIKONHE_GENERIC_ERROR;
        tile_in_data[i].in_len = len_slice_ext - 6;
        bofs += len_slice;
    }
    if (bofs > dec->data_len)
        return NIKONHE_GENERIC_ERROR;
    return NIKONHE_SUCCESS;
}

int LibRaw::nikonhe_decode_loop1_body(int i, int num_tiles, int tile_height, const void *tile_array, void *dec_ptr)
{
  nikonhe_decoder *dec = (nikonhe_decoder *)dec_ptr;
  nikonhe_image *img = &dec->img;
  tile_buf *tile_data = (tile_buf *)tile_array;
  stage1_data dec_data(img->line_stride);
  int tile_lines = i == num_tiles - 1 ? img->h_pix % tile_height : tile_height;
  return jpegxs_stage1_tile_decode(dec, i * tile_height, tile_lines, tile_data[i].in_buf, tile_data[i].in_len, &dec_data);
}


int LibRaw::nikonhe_decode_loop1(int num_tiles, int tile_height, const void *tile_array,void *dec_ptr)
{
#ifdef LIBRAW_USE_OPENMP
  int errcount = 0;
#pragma omp parallel for
#endif
  for (int i = 0; i < num_tiles; ++i)
  {
	  int rv = nikonhe_decode_loop1_body(i, num_tiles, tile_height, tile_array, dec_ptr);
#ifdef LIBRAW_USE_OPENMP
#pragma omp atomic
	  errcount += rv;
#else
	  if (rv)
		  return rv;
#endif
  }
#ifdef LIBRAW_USE_OPENMP
  return -errcount;
#else
  return 0;
#endif
}

int LibRaw::nikonhe_decode_loop2_body(int i, int num_tiles, int tile_height, void* dec_ptr)
{
  nikonhe_decoder *dec = (nikonhe_decoder *)dec_ptr;
  nikonhe_image *img = &dec->img;

  int tile_start = i * tile_height;
  int tile_lines = i == num_tiles - 1 ? img->h_pix % tile_height : tile_height;
  if (i == num_tiles - 1)
    tile_lines = img->h_pix - tile_height * i;
  iqx_iqp_tile_step1(&dec->in_bayer_stage1[img->line_stride * tile_start + 2 * img->semi_comp_chunks[0]],
                     &dec->in_bayer_stage1[img->line_stride * tile_start],
                     &dec->in_bayer_stage1[img->line_stride * tile_start + 2 * img->semi_comp_chunks[0] +
                                           2 * img->semi_comp_chunks[1] + 2 * img->semi_comp_chunks[3]],
                     &dec->in_bayer_stage1[img->line_stride * tile_start + 2 * img->semi_comp_chunks[0] +
                                           2 * img->semi_comp_chunks[1]],
                     &dec->in_bayer_stage2[img->line_stride * tile_start],
                     &dec->in_bayer_stage2[img->line_stride * tile_start + 2 * img->semi_comp_chunks[0]], img->w_pix,
                     tile_lines, img->line_stride, img->line_stride, tile_start == 0,
                     tile_start + tile_lines >= img->h_pix);

  return 0;
}

int LibRaw::nikonhe_decode_loop2(int num_tiles, int tile_height, void *dec_ptr)
{
#ifdef LIBRAW_USE_OPENMP
#pragma omp parallel for
#endif
  for (int i = 0; i < num_tiles; ++i)
  {
    nikonhe_decode_loop2_body(i, num_tiles, tile_height, dec_ptr);
  }
  return 0;
}

int LibRaw::nikonhe_decode_loop3_body(int i, int num_tiles, int tile_height, void *dec_ptr)
{
  nikonhe_decoder *dec = (nikonhe_decoder *)dec_ptr;
  nikonhe_image *img = &dec->img;

  int tile_start = i * tile_height;
  int tile_lines = i == num_tiles - 1 ? img->h_pix - img->h_pad_pix / 2 - tile_height * i : tile_height;

  int  rv =
      iqx_iqp_tile_step2(&dec->in_bayer_stage1[img->line_stride * tile_start + 2 * img->semi_comp_chunks[0]],
                         &dec->in_bayer_stage2[img->line_stride * tile_start],
                         &dec->in_bayer_stage2[img->line_stride * tile_start + 2 * img->semi_comp_chunks[0]],
                         &dec->in_bayer_stage1[img->line_stride * tile_start + 2 * img->semi_comp_chunks[0] +
                                               2 * img->semi_comp_chunks[1]],
                         tile_start, img->line_stride, img->line_stride, img->w_pix, tile_lines,
                         2 * img->h_pix - img->h_pad_pix, 2 * img->w_pix, tile_start == 0,
                         tile_start + tile_lines >= img->h_pix, dec, img->input_scale - img->depth, img->depth);

    return rv;

}

int LibRaw::nikonhe_decode_loop3(int num_tiles, int tile_height,  void *dec_ptr)
{
#ifdef LIBRAW_USE_OPENMP
  int errcount = 0;
#pragma omp parallel for
#endif
  for (int i = 0; i < num_tiles; ++i)
  {
    int rv = nikonhe_decode_loop3_body(i, num_tiles, tile_height, dec_ptr);
#ifdef LIBRAW_USE_OPENMP
#pragma omp atomic
    errcount += rv;
#else
    if (rv)
      return rv;
#endif
  }
#ifdef LIBRAW_USE_OPENMP
  return -errcount;
#else
  return 0;
#endif
}


int LibRaw:: nikonhe_decode_loop(void* dec_ptr)
{

	nikonhe_decoder* dec = (nikonhe_decoder*)dec_ptr;
    nikonhe_image* img = &dec->img;

    // allocate intermediate buffers
    size_t bayerBufSize = ((img->h_pix + 3) & ~3) * img->line_stride;
    std::vector<int32_t> bayer_storage_buf(2*bayerBufSize);
    dec->in_bayer_stage1 = bayer_storage_buf.data();
    dec->in_bayer_stage2 = dec->in_bayer_stage1 + bayerBufSize;

    if (img->gamma_data.enabled)
        calc_gamma_lut(&dec->gamma_lut, &img->gamma_data);

    // set the tiles to be slice high
    int tile_height = std::max(img->slh_pix, 1);
    int num_tiles = (tile_height + img->h_pix - 1) / tile_height;
    if (img->h_pix % tile_height > 0 && img->h_pix % tile_height <= img->v_lines)
        --num_tiles;

    // pre-populate data offsets and length for all tiles
    std::vector<tile_buf> tile_in_data(num_tiles);
    int rv = calc_tile_data_offsets(dec, num_tiles, tile_height, tile_in_data);
    if (rv != NIKONHE_SUCCESS)
        return rv;

    // decoding stage 0 - parse the precincts and extract code coeffs
    rv = nikonhe_decode_loop1(num_tiles, tile_height, tile_in_data.data(), dec_ptr);
    if (rv != NIKONHE_SUCCESS)
      return rv;

    // bayer inverse tile conversion step 1
    num_tiles = (tile_height + img->h_pix - 1) / tile_height;
    if (img->h_pix % tile_height == 1)
        --num_tiles;

    nikonhe_decode_loop2(num_tiles, tile_height, dec_ptr);

    // bayer inverse tile conversion step 2
    num_tiles = (tile_height + img->h_pix - img->h_pad_pix / 2 - 1)
                        / tile_height;

    rv = nikonhe_decode_loop3(num_tiles, tile_height, dec_ptr);

    return rv;
}

static err_code_t probe_image(
        nikonhe_decoder *decoder,
        size_t input_buffer_size,
        const void *input_buffer)
{
    const uint8_t* hdr_buf = (const uint8_t*)input_buffer;
    if (input_buffer_size < JPEG_XS_HEADER_SIZE)
        return NIKONHE_GENERIC_ERROR;
    nikonhe_image* img = &decoder->img;
    decoder->data_buf = (const uint8_t*)input_buffer;
    decoder->data_len = input_buffer_size;

    if (!hdr_buf)
        return NIKONHE_GENERIC_ERROR;

    size_t hdr_buf_len = input_buffer_size;

    img->is_422 = 0;
    img->is_nikonhe_long_packet_hdr = 0;
    memset(img->skip_decomp, 0, sizeof(img->skip_decomp));
    memset(&img->gamma_data, 0, sizeof(img->gamma_data));
    int hdr_len = jpeg_xs_parse_file_header(img, hdr_buf, hdr_buf_len);
    if (hdr_len < 0)
        return (err_code_t)hdr_len;
    if (hdr_buf_len < hdr_len)
        return NIKONHE_GENERIC_ERROR;

    decoder->data_ofs = hdr_len;

    return NIKONHE_SUCCESS;
}


void LibRaw::nikon_he_load_raw()
{
    if (libraw_internal_data.unpacker_data.data_size < 100 ||
            libraw_internal_data.unpacker_data.data_size > INT64(imgdata.sizes.raw_width) * INT64(imgdata.sizes.raw_height) * 4ULL) // 4bytes/pix limit
        throw LIBRAW_EXCEPTION_IO_BADFILE;

    std::vector<uint8_t> rawdata(libraw_internal_data.unpacker_data.data_size);
    int bytes =
            libraw_internal_data.internal_data.input->read(rawdata.data(), 1, libraw_internal_data.unpacker_data.data_size);
    if (bytes < libraw_internal_data.unpacker_data.data_size)
        throw LIBRAW_EXCEPTION_IO_EOF;

    std::vector<uint8_t> storage(sizeof(nikonhe_decoder));
    nikonhe_decoder* decoder = (nikonhe_decoder*)storage.data();

    int rv = probe_image(decoder, bytes, rawdata.data());

    if (rv != NIKONHE_SUCCESS)
        throw LIBRAW_EXCEPTION_DECODE_RAW;

    unsigned rwidth = get_image_width(decoder);
    unsigned rheight = get_image_height(decoder);

    if (imgdata.sizes.raw_width != rwidth || imgdata.sizes.raw_height != rheight)
        throw LIBRAW_EXCEPTION_DECODE_RAW;

    if (!decoder->data_buf || rwidth % 2 || (decoder->img.is_422 && rwidth % 16))
         throw LIBRAW_EXCEPTION_DECODE_RAW;

    decoder->output_height = (rheight + 1) / 2;
    decoder->output_line_stride = get_line_stride(rwidth) << 1;
    decoder->output_buffer = imgdata.rawdata.raw_image;

    rv = nikonhe_decode_loop(decoder);
	if(rv)
      throw LIBRAW_EXCEPTION_DECODE_RAW;
}
